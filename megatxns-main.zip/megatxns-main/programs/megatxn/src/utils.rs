use pinocchio::error::ProgramError;

use crate::error::MegaTxnError;

// Byte-reading helpers (offset-based, for instruction data parsing)

/// Cold error path — keeps inlined hot paths small.
#[cold]
#[inline(never)]
fn data_too_short(label: &str, offset: usize, need: usize, have: usize) -> ProgramError {
    pinocchio_log::log!(
        "{}: data too short at offset {} (need {}, have {})",
        label,
        offset,
        need,
        have
    );
    MegaTxnError::InvalidInstructionArgs.into()
}

#[inline(always)]
pub fn read_u8(data: &[u8], offset: usize, label: &str) -> Result<u8, ProgramError> {
    data.get(offset)
        .copied()
        .ok_or_else(|| data_too_short(label, offset, 1, data.len()))
}

#[inline(always)]
pub fn read_u16(data: &[u8], offset: usize, label: &str) -> Result<u16, ProgramError> {
    match data.get(offset..offset + 2) {
        Some(s) => Ok(u16::from_le_bytes(s.try_into().unwrap())),
        None => Err(data_too_short(label, offset, 2, data.len())),
    }
}

#[inline(always)]
pub fn read_bytes32(data: &[u8], offset: usize, label: &str) -> Result<[u8; 32], ProgramError> {
    match data.get(offset..offset + 32) {
        Some(s) => Ok(s.try_into().unwrap()),
        None => Err(data_too_short(label, offset, 32, data.len())),
    }
}

// Cursor — bounds-checked streaming reader over a byte slice

/// Zero-copy cursor into a `&[u8]`. Every read advances the position and
/// returns `InvalidTransactionMessage` on underflow — no raw index panics.
pub struct Cursor<'a>(pub &'a [u8]);

impl<'a> Cursor<'a> {
    #[inline(always)]
    pub fn u8(&mut self) -> Result<u8, ProgramError> {
        let (&b, rest) = self.0.split_first().ok_or::<ProgramError>(
            MegaTxnError::InvalidTransactionMessage.into(),
        )?;
        self.0 = rest;
        Ok(b)
    }

    #[inline(always)]
    pub fn u16_le(&mut self) -> Result<u16, ProgramError> {
        if self.0.len() < 2 {
            return Err(MegaTxnError::InvalidTransactionMessage.into());
        }
        let v = u16::from_le_bytes([self.0[0], self.0[1]]);
        self.0 = &self.0[2..];
        Ok(v)
    }

    #[inline(always)]
    pub fn take(&mut self, n: usize) -> Result<&'a [u8], ProgramError> {
        if self.0.len() < n {
            return Err(MegaTxnError::InvalidTransactionMessage.into());
        }
        let (head, tail) = self.0.split_at(n);
        self.0 = tail;
        Ok(head)
    }

    /// Remaining bytes in the cursor (not yet consumed).
    #[inline(always)]
    pub fn remaining(&self) -> &'a [u8] {
        self.0
    }
}

// MessageHeader — parsed metadata for a transaction message

/// Parsed offsets into a transaction message byte slice.
/// All fields reference positions within the original byte slice — no allocation.
pub struct MessageHeader<'a> {
    pub num_signers: u8,
    pub num_writable_signers: u8,
    pub num_writable_non_signers: u8,
    pub account_keys_count: usize,
    /// Slice of contiguous 32-byte pubkeys.
    pub account_keys: &'a [u8],
    /// Remaining bytes starting at the first instruction.
    pub instructions_data: &'a [u8],
    pub instructions_count: usize,
    /// Remaining bytes starting at the first lookup.
    pub lookups_data: &'a [u8],
    pub lookups_count: usize,
    pub total_loaded_writable: usize,
    pub total_loaded_readonly: usize,
}

impl MessageHeader<'_> {
    /// Total number of accounts addressable by this message.
    #[inline(always)]
    pub fn num_all_account_keys(&self) -> usize {
        self.account_keys_count + self.total_loaded_writable + self.total_loaded_readonly
    }

    /// Whether `idx` is a signer in the message.
    #[inline(always)]
    pub fn is_signer_index(&self, idx: usize) -> bool {
        idx < self.num_signers as usize
    }

    /// Whether `idx` references a writable account.
    #[inline(always)]
    pub fn is_writable_index(&self, idx: usize) -> bool {
        let ns = self.num_signers as usize;
        let nws = self.num_writable_signers as usize;
        let nwns = self.num_writable_non_signers as usize;

        if idx < self.account_keys_count {
            if idx < nws {
                return true;
            }
            if idx >= ns {
                return (idx - ns) < nwns;
            }
            return false;
        }
        let loaded_idx = idx - self.account_keys_count;
        loaded_idx < self.total_loaded_writable
    }
}

/// Parse a transaction message in SmallVec wire format. Returns a
/// `MessageHeader` holding slices into the original `msg` bytes.
pub fn parse_message_header(msg: &[u8]) -> Result<MessageHeader<'_>, ProgramError> {
    let mut c = Cursor(msg);

    let num_signers = c.u8()?;
    let num_writable_signers = c.u8()?;
    let num_writable_non_signers = c.u8()?;
    let account_keys_count = c.u8()? as usize;

    // Header sanity
    if num_writable_signers > num_signers
        || (num_signers as usize) > account_keys_count
        || (num_writable_non_signers as usize)
            > account_keys_count.saturating_sub(num_signers as usize)
    {
        return Err(MegaTxnError::InvalidTransactionMessage.into());
    }

    let account_keys = c.take(account_keys_count * 32)?;

    // Instructions — walk to find their extent and record the start slice.
    let instructions_count = c.u8()? as usize;
    let instructions_data = c.remaining();
    for _ in 0..instructions_count {
        let _program_id_index = c.u8()?;
        let acct_count = c.u8()? as usize;
        let _account_indexes = c.take(acct_count)?;
        let data_len = c.u16_le()? as usize;
        let _ix_data = c.take(data_len)?;
    }

    // Lookups — walk to compute totals.
    let lookups_count = c.u8()? as usize;
    let lookups_data = c.remaining();
    let mut total_loaded_writable = 0usize;
    let mut total_loaded_readonly = 0usize;
    for _ in 0..lookups_count {
        let _account_key = c.take(32)?;
        let writable_count = c.u8()? as usize;
        total_loaded_writable += writable_count;
        let _writable_indexes = c.take(writable_count)?;
        let readonly_count = c.u8()? as usize;
        total_loaded_readonly += readonly_count;
        let _readonly_indexes = c.take(readonly_count)?;
    }

    let num_all = account_keys_count + total_loaded_writable + total_loaded_readonly;

    // Second pass: validate instruction indexes are in bounds.
    let mut ic = Cursor(instructions_data);
    for _ in 0..instructions_count {
        let pid_index = ic.u8()? as usize;
        if pid_index >= num_all {
            return Err(MegaTxnError::InvalidTransactionMessage.into());
        }
        let acct_count = ic.u8()? as usize;
        let indexes = ic.take(acct_count)?;
        for &idx in indexes {
            if (idx as usize) >= num_all {
                return Err(MegaTxnError::InvalidTransactionMessage.into());
            }
        }
        let data_len = ic.u16_le()? as usize;
        let _ix_data = ic.take(data_len)?;
    }

    Ok(MessageHeader {
        num_signers,
        num_writable_signers,
        num_writable_non_signers,
        account_keys_count,
        account_keys,
        instructions_data,
        instructions_count,
        lookups_data,
        lookups_count,
        total_loaded_writable,
        total_loaded_readonly,
    })
}

/// Compute the SHA-256 hash of a byte slice (via Solana syscall).
#[inline(always)]
pub fn hash_message(data: &[u8]) -> [u8; 32] {
    solana_sha256_hasher::hashv(&[data]).to_bytes()
}
