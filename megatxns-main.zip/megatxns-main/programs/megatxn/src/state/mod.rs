pub mod transaction;
pub mod transaction_buffer;

use pinocchio::error::ProgramError;

use crate::error::MegaTxnError;

/// Account type discriminator — first byte of every program-owned account.
#[repr(u8)]
#[derive(Clone, Copy, PartialEq, Eq)]
pub enum AccountKey {
    Uninitialized = 0,
    MegaTransaction = 1,
    TransactionBuffer = 2,
}

impl AccountKey {
    pub fn min_data_len(&self) -> usize {
        match self {
            AccountKey::Uninitialized => 1,
            AccountKey::MegaTransaction => transaction::MegaTransactionHeader::LEN,
            AccountKey::TransactionBuffer => transaction_buffer::TransactionBufferHeader::LEN,
        }
    }
}

/// Validate the account discriminator byte and minimum data length.
#[inline(always)]
pub fn validate_account_key(data: &[u8], expected: AccountKey) -> Result<(), ProgramError> {
    if data.len() < expected.min_data_len() || data[0] != expected as u8 {
        let got = if data.is_empty() { 255 } else { data[0] };
        pinocchio_log::log!(
            "account_key: expected {}, got {} (len={})",
            expected as u8,
            got,
            data.len()
        );
        return Err(MegaTxnError::InvalidAccountKey.into());
    }
    Ok(())
}
