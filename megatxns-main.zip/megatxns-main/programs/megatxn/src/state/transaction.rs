use super::AccountKey;

/// MegaTransaction account layout (zero-copy):
///
/// ```text
/// [0]       account_key: u8           (AccountKey::MegaTransaction)
/// [1..33]   creator: [u8; 32]
/// [33]      ephemeral_signer_count: u8
/// [34..34+N]  ephemeral_signer_bumps: [u8; N]    (N = ephemeral_signer_count)
/// [34+N..]    message: [u8; M]                   (raw SmallVec wire format)
/// ```
#[repr(C)]
pub struct MegaTransactionHeader {
    pub account_key: u8,
    pub creator: [u8; 32],
    pub ephemeral_signer_count: u8,
}

impl MegaTransactionHeader {
    /// Size of the fixed header (before variable-length bumps + message).
    pub const LEN: usize = core::mem::size_of::<Self>();

    /// Total account size for a given ephemeral signer count and message length.
    #[inline(always)]
    pub fn account_size(ephemeral_count: u8, message_len: usize) -> usize {
        Self::LEN + ephemeral_count as usize + message_len
    }

    #[inline(always)]
    pub unsafe fn load(data: &[u8]) -> &Self {
        &*(data.as_ptr() as *const Self)
    }

    #[inline(always)]
    pub unsafe fn load_mut(data: &mut [u8]) -> &mut Self {
        &mut *(data.as_mut_ptr() as *mut Self)
    }

    /// Offset where ephemeral signer bumps start.
    #[inline(always)]
    pub fn bumps_offset() -> usize {
        Self::LEN
    }

    /// Offset where the message bytes start, given the ephemeral signer count.
    #[inline(always)]
    pub fn message_offset(ephemeral_count: u8) -> usize {
        Self::LEN + ephemeral_count as usize
    }

    #[inline(always)]
    pub fn init(&mut self, creator: [u8; 32], ephemeral_count: u8) {
        self.account_key = AccountKey::MegaTransaction as u8;
        self.creator = creator;
        self.ephemeral_signer_count = ephemeral_count;
    }
}
