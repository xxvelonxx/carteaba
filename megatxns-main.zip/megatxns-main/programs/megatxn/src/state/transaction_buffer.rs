use super::AccountKey;

/// TransactionBuffer account layout (zero-copy):
///
/// ```text
/// [0]       account_key: u8           (AccountKey::TransactionBuffer)
/// [1..33]   creator: [u8; 32]
/// [33]      buffer_index: u8
/// [34..66]  final_buffer_hash: [u8; 32]
/// [66..68]  final_buffer_size: u16 LE
/// [68..70]  current_size: u16 LE
/// [70..]    buffer: [u8; final_buffer_size]
/// ```
#[repr(C)]
pub struct TransactionBufferHeader {
    pub account_key: u8,
    pub creator: [u8; 32],
    pub buffer_index: u8,
    pub final_buffer_hash: [u8; 32],
    pub final_buffer_size: u16,
    pub current_size: u16,
}

impl TransactionBufferHeader {
    pub const LEN: usize = core::mem::size_of::<Self>();

    /// Total account size for a given final buffer size.
    #[inline(always)]
    pub fn account_size(final_buffer_size: u16) -> usize {
        Self::LEN + final_buffer_size as usize
    }

    #[inline(always)]
    pub unsafe fn load(data: &[u8]) -> &Self {
        &*(data.as_ptr() as *const Self)
    }

    #[inline(always)]
    pub unsafe fn load_mut(data: &mut [u8]) -> &mut Self {
        &mut *(data.as_mut_ptr() as *mut Self)
    }

    #[inline(always)]
    pub fn init(&mut self, creator: [u8; 32], buffer_index: u8, hash: [u8; 32], final_size: u16) {
        self.account_key = AccountKey::TransactionBuffer as u8;
        self.creator = creator;
        self.buffer_index = buffer_index;
        self.final_buffer_hash = hash;
        self.final_buffer_size = final_size;
        self.current_size = 0;
    }
}
