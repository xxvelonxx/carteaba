use pinocchio::{
    cpi::{Seed, Signer},
    sysvars::Sysvar,
    AccountView, Address, ProgramResult,
};
use pinocchio_system::instructions::CreateAccount;

use crate::{
    constants::*,
    error::MegaTxnError,
    state::{
        validate_account_key, AccountKey,
        transaction::MegaTransactionHeader,
        transaction_buffer::TransactionBufferHeader,
    },
    utils::{parse_message_header, read_u8},
    validation::{
        close_account, require_pda, require_signer, require_system_program, require_writable,
    },
};

/// Create a MegaTransaction from a completed transaction buffer.
///
/// # Instruction data
/// ```text
/// [0]  transaction_index: u8
/// [1]  ephemeral_signers: u8
/// ```
///
/// # Accounts
/// 0. `[writable]` MegaTransaction PDA
/// 1. `[signer]` Creator
/// 2. `[signer, writable]` Rent payer
/// 3. `[]` System program
/// 4. `[writable]` TransactionBuffer (closed after copy)
pub fn process(
    program_id: &Address,
    accounts: &[AccountView],
    data: &[u8],
) -> ProgramResult {
    extract_accounts!(accounts, exact [
        transaction, creator, rent_payer, system_program, buffer_account
    ]);

    require_signer(creator, "creator")?;
    require_signer(rent_payer, "rent_payer")?;
    require_writable(transaction, "transaction")?;
    require_writable(rent_payer, "rent_payer")?;
    require_writable(buffer_account, "buffer_account")?;
    require_system_program(system_program)?;

    let transaction_index = read_u8(data, 0, "transaction_index")?;
    let ephemeral_signers = read_u8(data, 1, "ephemeral_signers")?;

    if ephemeral_signers as usize > MAX_EPHEMERAL_SIGNERS {
        return Err(MegaTxnError::TooManyEphemeralSigners.into());
    }

    // Jito bundle safety
    if buffer_account.data_len() == 0 {
        pinocchio_log::log!("Warning: Transaction buffer is empty, fail silently for jito bundles");
        return Ok(());
    }

    // Validate transaction PDA before touching the buffer — fail fast on bad seeds.
    let idx_bytes = [transaction_index];
    let bump = require_pda(
        transaction,
        &[
            SEED_PREFIX,
            SEED_TRANSACTION,
            creator.address().as_ref(),
            &idx_bytes,
        ],
        program_id,
        "transaction",
    )?;

    if transaction.data_len() > 0 {
        pinocchio_log::log!("transaction account already initialized");
        return Err(MegaTxnError::InvalidAccount.into());
    }

    // Single buffer borrow — validate, CPI, copy, then drop before close.
    // CreateAccount CPI does not touch the buffer, so holding its borrow is safe.
    {
        let buf_data = buffer_account.try_borrow()?;
        validate_account_key(&buf_data, AccountKey::TransactionBuffer)?;

        let buf_header = unsafe { TransactionBufferHeader::load(&buf_data) };

        if &buf_header.creator != creator.address().as_array() {
            pinocchio_log::log!("buffer creator mismatch");
            return Err(MegaTxnError::Unauthorized.into());
        }
        if buf_header.current_size != buf_header.final_buffer_size {
            pinocchio_log::log!("buffer not complete");
            return Err(MegaTxnError::FinalBufferSizeMismatch.into());
        }

        let message_len = buf_header.current_size as usize;
        let buf_start = TransactionBufferHeader::LEN;
        let buffer_bytes = &buf_data[buf_start..buf_start + message_len];

        let computed_hash = crate::utils::hash_message(buffer_bytes);
        if computed_hash != buf_header.final_buffer_hash {
            pinocchio_log::log!("buffer hash mismatch");
            return Err(MegaTxnError::FinalBufferHashMismatch.into());
        }

        parse_message_header(buffer_bytes)?;

        // Create transaction account
        let account_size =
            MegaTransactionHeader::account_size(ephemeral_signers, message_len);
        let bump_bytes = [bump];
        let seeds = [
            Seed::from(SEED_PREFIX),
            Seed::from(SEED_TRANSACTION),
            Seed::from(creator.address().as_ref()),
            Seed::from(&idx_bytes[..]),
            Seed::from(&bump_bytes[..]),
        ];
        let signer = Signer::from(&seeds);

        CreateAccount {
            from: rent_payer,
            to: transaction,
            lamports: pinocchio::sysvars::rent::Rent::get()
                .map(|r| r.try_minimum_balance(account_size).unwrap_or(0))
                .unwrap_or(0),
            space: account_size as u64,
            owner: program_id,
        }
        .invoke_signed(&[signer])?;

        // Write transaction: header, bumps, message — all in one borrow.
        let mut txn_data = transaction.try_borrow_mut()?;
        let header = unsafe { MegaTransactionHeader::load_mut(&mut txn_data) };
        header.init(creator.address().to_bytes(), ephemeral_signers);

        let transaction_key = transaction.address();
        let bumps_start = MegaTransactionHeader::bumps_offset();
        for i in 0..ephemeral_signers as usize {
            let eph_idx = [i as u8];
            let eph_seeds: &[&[u8]] = &[
                SEED_PREFIX,
                transaction_key.as_ref(),
                SEED_EPHEMERAL_SIGNER,
                &eph_idx,
            ];
            let (_, eph_bump) = Address::find_program_address(eph_seeds, program_id);
            txn_data[bumps_start + i] = eph_bump;
        }

        // Copy directly from the still-live buffer borrow — no second borrow.
        let msg_start = MegaTransactionHeader::message_offset(ephemeral_signers);
        txn_data[msg_start..msg_start + message_len].copy_from_slice(buffer_bytes);
    }

    // Both borrows released — safe to close.
    close_account(buffer_account, creator)
}
