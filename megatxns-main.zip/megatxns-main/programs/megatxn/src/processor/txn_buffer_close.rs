use pinocchio::{AccountView, Address, ProgramResult};

use crate::{
    error::MegaTxnError,
    state::{validate_account_key, AccountKey},
    state::transaction_buffer::TransactionBufferHeader,
    validation::{close_account, require_owner, require_signer, require_writable},
};

/// Close a transaction buffer, returning lamports to the creator.
///
/// # Accounts
/// 0. `[writable]` TransactionBuffer account
/// 1. `[signer, writable]` Creator (rent recipient)
pub fn process(
    program_id: &Address,
    accounts: &[AccountView],
    _data: &[u8],
) -> ProgramResult {
    extract_accounts!(accounts, exact [buffer_account, creator]);

    require_signer(creator, "creator")?;
    require_writable(buffer_account, "buffer_account")?;
    require_writable(creator, "creator")?;
    require_owner(buffer_account, program_id, "buffer_account")?;

    {
        let account_data = buffer_account.try_borrow()?;
        validate_account_key(&account_data, AccountKey::TransactionBuffer)?;

        let header = unsafe { TransactionBufferHeader::load(&account_data) };
        if &header.creator != creator.address().as_array() {
            pinocchio_log::log!("creator mismatch");
            return Err(MegaTxnError::Unauthorized.into());
        }
    }

    close_account(buffer_account, creator)
}
