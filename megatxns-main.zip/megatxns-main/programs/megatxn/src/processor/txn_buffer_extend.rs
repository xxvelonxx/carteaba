use pinocchio::{AccountView, Address, ProgramResult};

use crate::{
    error::MegaTxnError,
    state::{validate_account_key, AccountKey},
    state::transaction_buffer::TransactionBufferHeader,
    validation::{require_owner, require_signer, require_writable},
};

/// Extend a transaction buffer with additional data.
///
/// # Instruction data
/// ```text
/// [0..] buffer: [u8; N] (data to append)
/// ```
///
/// # Accounts
/// 0. `[writable]` TransactionBuffer account
/// 1. `[signer]` Creator
pub fn process(
    program_id: &Address,
    accounts: &[AccountView],
    data: &[u8],
) -> ProgramResult {
    extract_accounts!(accounts, exact [buffer_account, creator]);

    require_signer(creator, "creator")?;

    // Jito bundle safety: if account is empty, fail silently
    if buffer_account.data_len() == 0 {
        pinocchio_log::log!("Warning: Transaction buffer is empty, fail silently for jito bundles");
        return Ok(());
    }

    require_writable(buffer_account, "buffer_account")?;
    require_owner(buffer_account, program_id, "buffer_account")?;

    // Single borrow — read header, validate, write extension, update size.
    let mut account_data = buffer_account.try_borrow_mut()?;
    validate_account_key(&account_data, AccountKey::TransactionBuffer)?;

    let (current_size, final_size) = {
        let header = unsafe { TransactionBufferHeader::load(&account_data) };
        if &header.creator != creator.address().as_array() {
            pinocchio_log::log!("creator mismatch");
            return Err(MegaTxnError::Unauthorized.into());
        }
        (header.current_size as usize, header.final_buffer_size as usize)
    };

    let new_data_len = data.len();
    let new_total = current_size + new_data_len;
    if new_total > final_size {
        pinocchio_log::log!("buffer extend exceeds final size");
        return Err(MegaTxnError::FinalBufferSizeExceeded.into());
    }

    account_data[TransactionBufferHeader::LEN + current_size
        ..TransactionBufferHeader::LEN + new_total]
        .copy_from_slice(data);

    unsafe { TransactionBufferHeader::load_mut(&mut account_data) }.current_size =
        new_total as u16;

    Ok(())
}
