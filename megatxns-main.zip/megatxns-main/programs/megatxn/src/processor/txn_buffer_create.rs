use pinocchio::{
    cpi::{Seed, Signer},
    sysvars::Sysvar,
    AccountView, Address, ProgramResult,
};
use pinocchio_system::instructions::CreateAccount;

use crate::{
    constants::*,
    error::MegaTxnError,
    state::transaction_buffer::TransactionBufferHeader,
    utils::{read_bytes32, read_u16, read_u8},
    validation::{require_pda, require_signer, require_system_program, require_writable},
};

/// Create a new transaction buffer account.
///
/// # Instruction data
/// ```text
/// [0]       buffer_index: u8
/// [1..33]   final_buffer_hash: [u8; 32]
/// [33..35]  final_buffer_size: u16 LE
/// [35..]    buffer: [u8; N] (initial slice)
/// ```
///
/// # Accounts
/// 0. `[writable]` TransactionBuffer PDA
/// 1. `[signer]` Creator
/// 2. `[signer, writable]` Rent payer
/// 3. `[]` System program
pub fn process(
    program_id: &Address,
    accounts: &[AccountView],
    data: &[u8],
) -> ProgramResult {
    extract_accounts!(accounts, exact [buffer_account, creator, rent_payer, system_program]);

    require_signer(creator, "creator")?;
    require_signer(rent_payer, "rent_payer")?;
    require_writable(buffer_account, "buffer_account")?;
    require_writable(rent_payer, "rent_payer")?;
    require_system_program(system_program)?;

    // Parse instruction data
    let buffer_index = read_u8(data, 0, "buffer_index")?;
    let final_buffer_hash = read_bytes32(data, 1, "final_buffer_hash")?;
    let final_buffer_size = read_u16(data, 33, "final_buffer_size")?;
    let initial_buffer = &data[35..];

    if (final_buffer_size as usize) > MAX_BUFFER_SIZE {
        return Err(MegaTxnError::FinalBufferSizeExceeded.into());
    }
    if initial_buffer.len() > final_buffer_size as usize {
        return Err(MegaTxnError::FinalBufferSizeExceeded.into());
    }

    // Validate PDA
    let bump = require_pda(
        buffer_account,
        &[
            SEED_PREFIX,
            SEED_TRANSACTION_BUFFER,
            creator.address().as_ref(),
            &[buffer_index],
        ],
        program_id,
        "buffer_account",
    )?;

    // Must be uninitialized
    if buffer_account.data_len() > 0 {
        pinocchio_log::log!("buffer account already initialized");
        return Err(MegaTxnError::InvalidAccount.into());
    }

    // Create the account
    let account_size = TransactionBufferHeader::account_size(final_buffer_size);
    let bump_bytes = [bump];
    let idx_bytes = [buffer_index];
    let seeds = [
        Seed::from(SEED_PREFIX),
        Seed::from(SEED_TRANSACTION_BUFFER),
        Seed::from(creator.address().as_ref()),
        Seed::from(&idx_bytes[..]),
        Seed::from(&bump_bytes[..]),
    ];
    let signer = Signer::from(&seeds);

    CreateAccount {
        from: rent_payer,
        to: buffer_account,
        lamports: pinocchio::sysvars::rent::Rent::get()
            .map(|r| r.try_minimum_balance(account_size).unwrap_or(0))
            .unwrap_or(0),
        space: account_size as u64,
        owner: program_id,
    }
    .invoke_signed(&[signer])?;

    // Write buffer bytes first (no header ref alive), then header once.
    let mut account_data = buffer_account.try_borrow_mut()?;
    let initial_len = initial_buffer.len();
    account_data[TransactionBufferHeader::LEN..TransactionBufferHeader::LEN + initial_len]
        .copy_from_slice(initial_buffer);

    let header = unsafe { TransactionBufferHeader::load_mut(&mut account_data) };
    header.init(
        creator.address().to_bytes(),
        buffer_index,
        final_buffer_hash,
        final_buffer_size,
    );
    header.current_size = initial_len as u16;

    Ok(())
}
