use pinocchio::{AccountView, Address, ProgramResult};

use crate::{
    error::MegaTxnError,
    state::{validate_account_key, AccountKey},
    state::transaction::MegaTransactionHeader,
    validation::{close_account, require_owner, require_signer, require_writable},
};

/// Close a MegaTransaction account, returning lamports to the creator.
/// Use this for cleanup when a transaction doesn't need to be executed.
///
/// # Accounts
/// 0. `[writable]` MegaTransaction account
/// 1. `[signer, writable]` Creator (rent recipient)
pub fn process(
    program_id: &Address,
    accounts: &[AccountView],
    _data: &[u8],
) -> ProgramResult {
    extract_accounts!(accounts, exact [transaction, creator]);

    require_signer(creator, "creator")?;
    require_writable(transaction, "transaction")?;
    require_writable(creator, "creator")?;
    require_owner(transaction, program_id, "transaction")?;

    {
        let account_data = transaction.try_borrow()?;
        validate_account_key(&account_data, AccountKey::MegaTransaction)?;

        let header = unsafe { MegaTransactionHeader::load(&account_data) };
        if &header.creator != creator.address().as_array() {
            pinocchio_log::log!("creator mismatch");
            return Err(MegaTxnError::Unauthorized.into());
        }
    }

    close_account(transaction, creator)
}
