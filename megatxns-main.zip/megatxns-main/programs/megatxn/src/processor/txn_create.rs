use pinocchio::{
    cpi::{Seed, Signer},
    sysvars::Sysvar,
    AccountView, Address, ProgramResult,
};
use pinocchio_system::instructions::CreateAccount;

use crate::{
    constants::*,
    error::MegaTxnError,
    state::transaction::MegaTransactionHeader,
    utils::{parse_message_header, read_u8},
    validation::{require_pda, require_signer, require_system_program, require_writable},
};

/// Create a MegaTransaction with an inline message (fits in one tx).
///
/// # Instruction data
/// ```text
/// [0]     transaction_index: u8
/// [1]     ephemeral_signers: u8
/// [2..]   transaction_message: [u8; N] (SmallVec wire format)
/// ```
///
/// # Accounts
/// 0. `[writable]` MegaTransaction PDA
/// 1. `[signer]` Creator
/// 2. `[signer, writable]` Rent payer
/// 3. `[]` System program
pub fn process(
    program_id: &Address,
    accounts: &[AccountView],
    data: &[u8],
) -> ProgramResult {
    extract_accounts!(accounts, exact [transaction, creator, rent_payer, system_program]);

    require_signer(creator, "creator")?;
    require_signer(rent_payer, "rent_payer")?;
    require_writable(transaction, "transaction")?;
    require_writable(rent_payer, "rent_payer")?;
    require_system_program(system_program)?;

    let transaction_index = read_u8(data, 0, "transaction_index")?;
    let ephemeral_signers = read_u8(data, 1, "ephemeral_signers")?;
    let message_bytes = &data[2..];

    if ephemeral_signers as usize > MAX_EPHEMERAL_SIGNERS {
        return Err(MegaTxnError::TooManyEphemeralSigners.into());
    }

    // Validate message format
    parse_message_header(message_bytes)?;

    // Validate PDA
    let idx_bytes = [transaction_index];
    let bump = require_pda(
        transaction,
        &[
            SEED_PREFIX,
            SEED_TRANSACTION,
            creator.address().as_ref(),
            &idx_bytes,
        ],
        program_id,
        "transaction",
    )?;

    if transaction.data_len() > 0 {
        pinocchio_log::log!("transaction account already initialized");
        return Err(MegaTxnError::InvalidAccount.into());
    }

    // Compute ephemeral signer bumps
    let account_size =
        MegaTransactionHeader::account_size(ephemeral_signers, message_bytes.len());
    let bump_bytes = [bump];
    let seeds = [
        Seed::from(SEED_PREFIX),
        Seed::from(SEED_TRANSACTION),
        Seed::from(creator.address().as_ref()),
        Seed::from(&idx_bytes[..]),
        Seed::from(&bump_bytes[..]),
    ];
    let signer = Signer::from(&seeds);

    CreateAccount {
        from: rent_payer,
        to: transaction,
        lamports: pinocchio::sysvars::rent::Rent::get()
            .map(|r| r.try_minimum_balance(account_size).unwrap_or(0))
            .unwrap_or(0),
        space: account_size as u64,
        owner: program_id,
    }
    .invoke_signed(&[signer])?;

    // Initialize
    let mut account_data = transaction.try_borrow_mut()?;
    let header = unsafe { MegaTransactionHeader::load_mut(&mut account_data) };
    header.init(creator.address().to_bytes(), ephemeral_signers);

    // Write ephemeral signer bumps
    let transaction_key = transaction.address();
    let bumps_start = MegaTransactionHeader::bumps_offset();
    for i in 0..ephemeral_signers as usize {
        let idx_byte = [i as u8];
        let eph_seeds: &[&[u8]] = &[
            SEED_PREFIX,
            transaction_key.as_ref(),
            SEED_EPHEMERAL_SIGNER,
            &idx_byte,
        ];
        let (_, eph_bump) = Address::find_program_address(eph_seeds, program_id);
        account_data[bumps_start + i] = eph_bump;
    }

    // Write message bytes
    let msg_start = MegaTransactionHeader::message_offset(ephemeral_signers);
    account_data[msg_start..msg_start + message_bytes.len()].copy_from_slice(message_bytes);

    Ok(())
}
