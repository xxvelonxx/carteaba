use pinocchio::{
    cpi::{self, Seed, Signer},
    error::ProgramError,
    instruction::{InstructionAccount, InstructionView},
    AccountView, Address, ProgramResult,
};

use crate::{
    constants::*,
    error::MegaTxnError,
    state::{validate_account_key, AccountKey},
    utils::{parse_message_header, Cursor, MessageHeader},
    validation::{close_account, require_owner, require_signer, require_writable},
};

/// Execute a MegaTransaction.
///
/// # Accounts
///
/// 0. `[writable]` MegaTransaction account (closed after execution)
/// 1. `[signer, writable]` Creator
/// 2.. Remaining accounts in this order:
///     a) ALT accounts (one per `address_table_lookups` entry)
///     b) Static accounts matching `message.account_keys`
///     c) ALL loaded writable accounts (from all ALTs, in order)
///     d) ALL loaded readonly accounts (from all ALTs, in order)
pub fn process(
    program_id: &Address,
    accounts: &[AccountView],
    _data: &[u8],
) -> ProgramResult {
    extract_accounts!(accounts, [transaction_account, creator], rest = remaining);

    require_signer(creator, "creator")?;
    require_writable(transaction_account, "transaction")?;
    require_writable(creator, "creator")?;

    // Jito bundle safety: if account is empty, fail silently
    if transaction_account.data_len() == 0 {
        pinocchio_log::log!("Warning: MegaTransaction is empty, fail silently for jito bundles");
        return Ok(());
    }

    require_owner(transaction_account, program_id, "transaction")?;

    // Phase 1: Read transaction account, validate, execute CPIs.
    // The borrow on transaction_account is held during CPI — safe because
    // the transaction account is NOT passed to any inner CPI call.
    {
        let data = transaction_account.try_borrow()?;
        validate_account_key(&data, AccountKey::MegaTransaction)?;

        if &data[1..33] != creator.address().as_array() {
            pinocchio_log::log!("creator mismatch");
            return Err(MegaTxnError::Unauthorized.into());
        }

        let ephemeral_count = data[33] as usize;
        if ephemeral_count > MAX_EPHEMERAL_SIGNERS {
            return Err(MegaTxnError::TooManyEphemeralSigners.into());
        }
        let bumps = &data[34..34 + ephemeral_count];
        let msg = &data[34 + ephemeral_count..];

        let header = parse_message_header(msg)?;
        let num_lookups = header.lookups_count;

        // Validate remaining accounts count
        let expected_remaining = num_lookups
            + header.account_keys_count
            + header.total_loaded_writable
            + header.total_loaded_readonly;
        if remaining.len() != expected_remaining {
            pinocchio_log::log!(
                "remaining accounts: expected {}, got {}",
                expected_remaining,
                remaining.len()
            );
            return Err(MegaTxnError::InvalidNumberOfAccounts.into());
        }

        let msg_accounts = &remaining[num_lookups..];

        // Derive ephemeral signer keys for signer-check exemption
        let tx_key = transaction_account.address();
        let mut ephemeral_keys: [[u8; 32]; MAX_EPHEMERAL_SIGNERS] =
            [[0u8; 32]; MAX_EPHEMERAL_SIGNERS];
        for i in 0..ephemeral_count {
            let idx_byte = [i as u8];
            let bump_byte = [bumps[i]];
            let seeds: &[&[u8]] = &[
                SEED_PREFIX,
                tx_key.as_ref(),
                SEED_EPHEMERAL_SIGNER,
                &idx_byte,
                &bump_byte,
            ];
            ephemeral_keys[i] = Address::create_program_address(seeds, program_id)
                .map_err(|_| ProgramError::InvalidSeeds)?
                .to_bytes();
        }

        // Validate static accounts
        for i in 0..header.account_keys_count {
            let expected_key = &header.account_keys[i * 32..(i + 1) * 32];
            let actual = &msg_accounts[i];
            if actual.address().as_array() != expected_key {
                pinocchio_log::log!("static account mismatch at index {}", i as u64);
                return Err(MegaTxnError::InvalidAccount.into());
            }
            if header.is_signer_index(i)
                && actual.address() != creator.address()
                && !is_ephemeral_key(actual.address(), &ephemeral_keys, ephemeral_count)
            {
                if !actual.is_signer() {
                    pinocchio_log::log!("static account not signer at index {}", i as u64);
                    return Err(MegaTxnError::InvalidAccount.into());
                }
            }
            if header.is_writable_index(i) && !actual.is_writable() {
                pinocchio_log::log!("static account not writable at index {}", i as u64);
                return Err(MegaTxnError::InvalidAccount.into());
            }
        }

        // Validate ALT loaded accounts
        validate_alt_loaded_accounts(&header, remaining, num_lookups)?;

        // Execute instructions — seed/signer construction happens inside each CPI
        let tx_key_ref: &[u8] = tx_key.as_ref();
        let mut c = Cursor(header.instructions_data);
        for _ in 0..header.instructions_count {
            let program_id_index = c.u8()? as usize;
            let acct_count = c.u8()? as usize;
            let account_indexes = c.take(acct_count)?;
            let data_len = c.u16_le()? as usize;
            let ix_data = c.take(data_len)?;

            execute_cpi(
                program_id_index, account_indexes, ix_data, msg_accounts,
                &header, tx_key_ref, bumps, ephemeral_count,
            )?;
        }
    }

    // Phase 2: Close the transaction account (borrow released)
    close_account(transaction_account, creator)
}

/// Check if an address is one of the pre-derived ephemeral signer keys.
#[inline(always)]
fn is_ephemeral_key(
    address: &Address,
    keys: &[[u8; 32]; MAX_EPHEMERAL_SIGNERS],
    count: usize,
) -> bool {
    for i in 0..count {
        if address.as_array() == &keys[i] {
            return true;
        }
    }
    false
}

/// Validate that loaded accounts from ALTs match the expected addresses and modifiers.
fn validate_alt_loaded_accounts(
    header: &MessageHeader,
    remaining: &[AccountView],
    num_lookups: usize,
) -> ProgramResult {
    let alt_accounts = &remaining[..num_lookups];
    let msg_accounts = &remaining[num_lookups..];

    let mut c = Cursor(header.lookups_data);
    let mut writable_cursor = header.account_keys_count;
    let mut readonly_cursor = header.account_keys_count + header.total_loaded_writable;

    for i in 0..num_lookups {
        let alt_account = &alt_accounts[i];

        // ALT must be owned by the ALT program
        let alt_owner = unsafe { alt_account.owner() };
        if *alt_owner != ALT_PROGRAM_ID {
            pinocchio_log::log!("ALT {} not owned by ALT program", i as u64);
            return Err(MegaTxnError::InvalidAccount.into());
        }

        // ALT address must match the one in the message
        let expected_alt_key = c.take(32)?;
        if alt_account.address().as_array() != expected_alt_key {
            pinocchio_log::log!("ALT address mismatch at index {}", i as u64);
            return Err(MegaTxnError::InvalidAccount.into());
        }

        // Read ALT data to verify loaded addresses
        let alt_data = alt_account.try_borrow()?;

        // Writable loaded accounts
        let writable_count = c.u8()? as usize;
        let writable_indexes = c.take(writable_count)?;
        for &idx_in_alt in writable_indexes {
            let addr_start = ALT_HEADER_SIZE + (idx_in_alt as usize) * 32;
            let addr_end = addr_start + 32;
            if addr_end > alt_data.len() {
                pinocchio_log::log!("ALT index {} out of bounds", idx_in_alt as u64);
                return Err(MegaTxnError::InvalidAccount.into());
            }
            let actual = &msg_accounts[writable_cursor];
            if actual.address().as_array() != &alt_data[addr_start..addr_end] {
                pinocchio_log::log!("writable loaded account mismatch");
                return Err(MegaTxnError::InvalidAccount.into());
            }
            if !actual.is_writable() {
                pinocchio_log::log!("loaded account not writable");
                return Err(MegaTxnError::InvalidAccount.into());
            }
            writable_cursor += 1;
        }

        // Readonly loaded accounts
        let readonly_count = c.u8()? as usize;
        let readonly_indexes = c.take(readonly_count)?;
        for &idx_in_alt in readonly_indexes {
            let addr_start = ALT_HEADER_SIZE + (idx_in_alt as usize) * 32;
            let addr_end = addr_start + 32;
            if addr_end > alt_data.len() {
                pinocchio_log::log!("ALT index {} out of bounds", idx_in_alt as u64);
                return Err(MegaTxnError::InvalidAccount.into());
            }
            let actual = &msg_accounts[readonly_cursor];
            if actual.address().as_array() != &alt_data[addr_start..addr_end] {
                pinocchio_log::log!("readonly loaded account mismatch");
                return Err(MegaTxnError::InvalidAccount.into());
            }
            readonly_cursor += 1;
        }
    }

    Ok(())
}

// CPI execution

/// Build and execute a single inner CPI instruction.
///
/// Metas and account_view refs are heap-allocated (Vec, exact capacity).
/// `invoke_signed_with_slice` handles CpiAccount conversion internally
/// via `Box::new_uninit_slice` — no stack pressure, no hardcoded account cap.
/// The only limit is pinocchio's `MAX_CPI_ACCOUNTS` (128, 255 after SIMD-0339),
/// which tracks Solana's runtime limit automatically.
fn execute_cpi(
    program_id_index: usize,
    account_indexes: &[u8],
    ix_data: &[u8],
    msg_accounts: &[AccountView],
    header: &MessageHeader,
    tx_key: &[u8],
    bumps: &[u8],
    ephemeral_count: usize,
) -> ProgramResult {
    use alloc::vec::Vec;

    let num_accounts = account_indexes.len();
    let program_view = msg_accounts
        .get(program_id_index)
        .ok_or(ProgramError::InvalidArgument)?;

    let mut metas = Vec::with_capacity(num_accounts);
    let mut views: Vec<&AccountView> = Vec::with_capacity(num_accounts + 1);

    for &idx in account_indexes {
        let idx = idx as usize;
        let view = msg_accounts
            .get(idx)
            .ok_or(ProgramError::InvalidArgument)?;
        metas.push(InstructionAccount::new(
            view.address(),
            header.is_writable_index(idx),
            header.is_signer_index(idx),
        ));
        views.push(view);
    }
    // Program ID must be in account_views (runtime needs it) but NOT in metas
    // (the inner instruction doesn't list the program as an account operand).
    views.push(program_view);

    let ix = InstructionView {
        program_id: program_view.address(),
        accounts: &metas,
        data: ix_data,
    };

    // Fast path: no ephemeral signers (common case)
    if ephemeral_count == 0 {
        return cpi::invoke_signed_with_slice(&ix, &views, &[]);
    }

    // Cold path: build ephemeral signer seeds on the stack.
    const IDX: [[u8; 1]; MAX_EPHEMERAL_SIGNERS] = [[0], [1], [2], [3], [4], [5], [6], [7]];

    let bump_storage: [[u8; 1]; MAX_EPHEMERAL_SIGNERS] = {
        let mut out = [[0u8; 1]; MAX_EPHEMERAL_SIGNERS];
        let mut i = 0;
        while i < bumps.len() && i < MAX_EPHEMERAL_SIGNERS {
            out[i] = [bumps[i]];
            i += 1;
        }
        out
    };

    let seed_storage: [[Seed; 5]; MAX_EPHEMERAL_SIGNERS] = core::array::from_fn(|i| {
        [
            Seed::from(SEED_PREFIX),
            Seed::from(tx_key),
            Seed::from(SEED_EPHEMERAL_SIGNER),
            Seed::from(&IDX[i][..]),
            Seed::from(&bump_storage[i][..]),
        ]
    });

    let signers: [Signer; MAX_EPHEMERAL_SIGNERS] =
        core::array::from_fn(|i| Signer::from(&seed_storage[i][..]));

    cpi::invoke_signed_with_slice(&ix, &views, &signers[..ephemeral_count])
}
