/// Destructure an `&[AccountView]` slice into named local bindings with labeled,
/// logged errors on missing slots.
///
/// Two forms:
///
/// * Lenient — extra trailing accounts are allowed (use `rest = name` to bind them):
///
/// ```ignore
/// extract_accounts!(accounts, [
///     transaction,
///     creator,
/// ], rest = remaining);
/// ```
///
/// * Exact — `accounts.len()` must equal the number of named slots:
///
/// ```ignore
/// extract_accounts!(accounts, exact [
///     transaction,
///     creator,
///     system_program,
/// ]);
/// ```
#[macro_export]
macro_rules! extract_accounts {
    // Exact form: rejects both too-few and too-many.
    ($accounts:expr, exact [ $($name:ident),+ $(,)? ] $(,)?) => {
        let __accts: &[pinocchio::AccountView] = $accounts;
        const __EXPECTED: usize = <[()]>::len(&[$( $crate::extract_accounts!(@unit $name) ),+]);
        if __accts.len() > __EXPECTED {
            pinocchio_log::log!(
                "unexpected extra accounts: expected {}, got {}",
                __EXPECTED as u64,
                __accts.len() as u64
            );
            return Err(pinocchio::error::ProgramError::InvalidArgument);
        }
        let mut __idx: usize = 0;
        $(
            let $name: &pinocchio::AccountView = match __accts.get(__idx) {
                Some(a) => a,
                None => {
                    pinocchio_log::log!(
                        "missing account {} at index {} (got {} accounts)",
                        stringify!($name),
                        __idx as u64,
                        __accts.len() as u64
                    );
                    return Err(pinocchio::error::ProgramError::NotEnoughAccountKeys);
                }
            };
            #[allow(unused_assignments)]
            { __idx += 1; }
        )+
    };

    // Lenient form: trailing extras are allowed, optional `rest = name` slice tail.
    ($accounts:expr, [ $($name:ident),+ $(,)? ] $(, rest = $rest:ident)? $(,)?) => {
        let __accts: &[pinocchio::AccountView] = $accounts;
        let mut __idx: usize = 0;
        $(
            let $name: &pinocchio::AccountView = match __accts.get(__idx) {
                Some(a) => a,
                None => {
                    pinocchio_log::log!(
                        "missing account {} at index {} (got {} accounts)",
                        stringify!($name),
                        __idx as u64,
                        __accts.len() as u64
                    );
                    return Err(pinocchio::error::ProgramError::NotEnoughAccountKeys);
                }
            };
            #[allow(unused_assignments)]
            { __idx += 1; }
        )+
        $( let $rest: &[pinocchio::AccountView] = &__accts[__idx..]; )?
    };

    // Internal helper: count idents by mapping each to `()`.
    (@unit $_name:ident) => { () };
}
