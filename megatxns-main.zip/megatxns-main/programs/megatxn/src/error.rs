use pinocchio::error::ProgramError;

#[repr(u32)]
pub enum MegaTxnError {
    Unauthorized = 6000,
    InvalidAccount = 6001,
    InvalidNumberOfAccounts = 6002,
    InvalidTransactionMessage = 6003,
    FinalBufferSizeExceeded = 6004,
    FinalBufferHashMismatch = 6005,
    FinalBufferSizeMismatch = 6006,
    InvalidInstructionArgs = 6007,
    MathOverflow = 6008,
    AccountNotWritable = 6009,
    MissingRequiredSignature = 6010,
    InvalidPDA = 6011,
    InvalidAccountOwner = 6012,
    InvalidAccountKey = 6013,
    TooManyEphemeralSigners = 6014,
    TooManyInstructionAccounts = 6015,
}

impl From<MegaTxnError> for ProgramError {
    fn from(e: MegaTxnError) -> Self {
        ProgramError::Custom(e as u32)
    }
}
