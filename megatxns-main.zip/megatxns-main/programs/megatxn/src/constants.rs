use pinocchio::Address;

pub const SEED_PREFIX: &[u8] = b"megatxn";
pub const SEED_TRANSACTION: &[u8] = b"transaction";
pub const SEED_EPHEMERAL_SIGNER: &[u8] = b"ephemeral_signer";
pub const SEED_TRANSACTION_BUFFER: &[u8] = b"txn_buffer";

/// Maximum PDA allocation size in an inner ix is 10240 bytes.
/// 10240 - header overhead = ~10160 bytes.
pub const MAX_BUFFER_SIZE: usize = 10160;

/// Maximum number of ephemeral signers per transaction.
pub const MAX_EPHEMERAL_SIGNERS: usize = 8;

/// Solana Address Lookup Table program ID.
pub const ALT_PROGRAM_ID: Address = Address::new_from_array(
    five8_const::decode_32_const("AddressLookupTab1e1111111111111111111111111"),
);

/// Byte offset where addresses begin in an ALT account.
pub const ALT_HEADER_SIZE: usize = 56;
