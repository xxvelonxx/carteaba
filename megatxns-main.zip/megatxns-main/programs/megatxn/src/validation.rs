use pinocchio::{error::ProgramError, AccountView, Address, ProgramResult};

use crate::error::MegaTxnError;

/// Close a program-owned account: transfer lamports to recipient, then zero the account.
#[inline(always)]
pub fn close_account(account: &AccountView, recipient: &AccountView) -> ProgramResult {
    recipient.set_lamports(
        recipient
            .lamports()
            .checked_add(account.lamports())
            .ok_or::<ProgramError>(MegaTxnError::MathOverflow.into())?,
    );
    account.close()
}

#[inline(always)]
pub fn require_signer(account: &AccountView, label: &str) -> Result<(), ProgramError> {
    if !account.is_signer() {
        pinocchio_log::log!("{}: not a signer", label);
        return Err(MegaTxnError::MissingRequiredSignature.into());
    }
    Ok(())
}

#[inline(always)]
pub fn require_writable(account: &AccountView, label: &str) -> Result<(), ProgramError> {
    if !account.is_writable() {
        pinocchio_log::log!("{}: not writable", label);
        return Err(MegaTxnError::AccountNotWritable.into());
    }
    Ok(())
}

#[inline(always)]
pub fn require_owner(
    account: &AccountView,
    expected: &Address,
    label: &str,
) -> Result<(), ProgramError> {
    let account_owner = unsafe { account.owner() };
    if account_owner != expected {
        pinocchio_log::log!("{}: unexpected owner", label);
        return Err(MegaTxnError::InvalidAccountOwner.into());
    }
    Ok(())
}

/// Validates that an account matches the expected PDA derivation.
/// Returns the bump seed on success.
#[inline(always)]
pub fn require_pda(
    account: &AccountView,
    seeds: &[&[u8]],
    program_id: &Address,
    label: &str,
) -> Result<u8, ProgramError> {
    let (expected, bump) = Address::find_program_address(seeds, program_id);
    if *account.address() != expected {
        pinocchio_log::log!("{}: PDA mismatch", label);
        return Err(MegaTxnError::InvalidPDA.into());
    }
    Ok(bump)
}

/// Validates that the account is the system program.
#[inline(always)]
pub fn require_system_program(account: &AccountView) -> Result<(), ProgramError> {
    if *account.address() != pinocchio_system::ID {
        return Err(ProgramError::IncorrectProgramId);
    }
    Ok(())
}
