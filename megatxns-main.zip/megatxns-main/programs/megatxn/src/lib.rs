#![no_std]

extern crate alloc;

pub mod allocator;
pub mod constants;
pub mod error;
#[macro_use]
pub mod macros;
pub mod processor;
pub mod state;
pub mod utils;
pub mod validation;

#[cfg(not(feature = "no-entrypoint"))]
mod entrypoint {
    use pinocchio::{
        error::ProgramError, nostd_panic_handler, program_entrypoint, AccountView, Address,
        ProgramResult,
    };

    use crate::{mega_txn_heap_allocator, processor};

    program_entrypoint!(process_instruction);
    nostd_panic_handler!();
    mega_txn_heap_allocator!();

    pub fn process_instruction(
        program_id: &Address,
        accounts: &[AccountView],
        data: &[u8],
    ) -> ProgramResult {
        if data.is_empty() {
            return Err(ProgramError::InvalidInstructionData);
        }

        let discriminant = data[0];
        let instruction_data = &data[1..];

        match discriminant {
            0 => {
                pinocchio_log::log!("ixn: txn_buffer_create");
                processor::txn_buffer_create::process(program_id, accounts, instruction_data)
            }
            1 => {
                pinocchio_log::log!("ixn: txn_buffer_extend");
                processor::txn_buffer_extend::process(program_id, accounts, instruction_data)
            }
            2 => {
                pinocchio_log::log!("ixn: txn_buffer_close");
                processor::txn_buffer_close::process(program_id, accounts, instruction_data)
            }
            3 => {
                pinocchio_log::log!("ixn: txn_create");
                processor::txn_create::process(program_id, accounts, instruction_data)
            }
            4 => {
                pinocchio_log::log!("ixn: txn_create_from_buffer");
                processor::txn_create_from_buffer::process(program_id, accounts, instruction_data)
            }
            5 => {
                pinocchio_log::log!("ixn: txn_execute");
                processor::txn_execute::process(program_id, accounts, instruction_data)
            }
            6 => {
                pinocchio_log::log!("ixn: txn_close");
                processor::txn_close::process(program_id, accounts, instruction_data)
            }
            _ => {
                pinocchio_log::log!("ixn: unknown discriminant");
                Err(ProgramError::InvalidInstructionData)
            }
        }
    }
}
