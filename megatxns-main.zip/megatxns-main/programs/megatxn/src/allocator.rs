use core::alloc::{GlobalAlloc, Layout};
use core::ptr;

/// Exclusive upper bound of the heap region the Solana runtime may make
/// available to a program.
const HEAP_END_ADDRESS: usize = 0x400000000;

/// Bump allocator that grows upward from HEAP_START.
///
/// Trade-offs:
/// - Uses all heap the runtime provides (can be expanded via
///   `RequestHeapFrame` up to 256KB), not just the default 32KB.
/// - Never frees. Memory usage is cumulative across allocations;
///   unsuitable for workloads that allocate and drop repeatedly.
///   Prefer zero-copy parsing and reused scratch buffers over churning
///   `Vec`s in hot loops.
/// - Relies on the BPF runtime zero-initializing the heap region so the
///   position pointer at `HEAP_START` reads as `0` on first allocation.
pub struct MegaTxnHeapAllocator;

unsafe impl GlobalAlloc for MegaTxnHeapAllocator {
    #[inline]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let heap_start = pinocchio::entrypoint::HEAP_START_ADDRESS as usize;
        let pos_ptr = heap_start as *mut usize;

        let mut pos = *pos_ptr;
        if pos == 0 {
            // Reserve space for the position pointer itself.
            pos = heap_start + core::mem::size_of::<usize>();
        }

        // Align `pos` up to `layout.align()` (guaranteed power of two).
        let mask = layout.align().wrapping_sub(1);
        let begin = pos.wrapping_add(mask) & !mask;

        let Some(end) = begin.checked_add(layout.size()) else {
            return ptr::null_mut();
        };
        if end >= HEAP_END_ADDRESS {
            return ptr::null_mut();
        }

        *pos_ptr = end;
        begin as *mut u8
    }

    #[inline]
    unsafe fn dealloc(&self, _: *mut u8, _: Layout) {
        // Bump allocator: no per-allocation free.
    }

    #[inline]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        // Heap region is zero-initialized and never reused, so fresh
        // allocations are already zero.
        self.alloc(layout)
    }
}

#[macro_export]
macro_rules! mega_txn_heap_allocator {
    () => {
        #[cfg(target_os = "solana")]
        #[global_allocator]
        static __MEGATXN_ALLOCATOR: $crate::allocator::MegaTxnHeapAllocator =
            $crate::allocator::MegaTxnHeapAllocator;
    };
}
