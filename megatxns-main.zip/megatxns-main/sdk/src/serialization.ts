import {
  TransactionMessage,
  AddressLookupTableAccount,
  PublicKey,
} from "@solana/web3.js";
import { compileToWrappedMessageV0 } from "./utils/compileToWrappedMessageV0.js";

// Types matching the on-chain SmallVec wire format

export type CompiledMsInstruction = {
  programIdIndex: number;
  accountIndexes: number[];
  data: number[];
};

export type MessageAddressTableLookupData = {
  accountKey: PublicKey;
  writableIndexes: number[];
  readonlyIndexes: number[];
};

export type MegaTransactionMessage = {
  numSigners: number;
  numWritableSigners: number;
  numWritableNonSigners: number;
  accountKeys: PublicKey[];
  instructions: CompiledMsInstruction[];
  addressTableLookups: MessageAddressTableLookupData[];
};

// Serialize: TransactionMessage → SmallVec wire bytes

/**
 * Serialize a TransactionMessage into the MegaTxn SmallVec wire format.
 *
 * Uses `compileToWrappedMessageV0` so instruction programIds can be resolved
 * from ALTs (unlike the standard `compileToV0Message`).
 */
export function serializeTransactionMessage(
  message: TransactionMessage,
  addressLookupTableAccounts?: AddressLookupTableAccount[]
): Buffer {
  const compiled = compileToWrappedMessageV0({
    payerKey: message.payerKey,
    recentBlockhash: message.recentBlockhash,
    instructions: message.instructions,
    addressLookupTableAccounts,
  });

  const numSigners = compiled.header.numRequiredSignatures;
  const numWritableSigners =
    numSigners - compiled.header.numReadonlySignedAccounts;
  const numWritableNonSigners =
    compiled.staticAccountKeys.length -
    numSigners -
    compiled.header.numReadonlyUnsignedAccounts;

  const msg: MegaTransactionMessage = {
    numSigners,
    numWritableSigners,
    numWritableNonSigners,
    accountKeys: compiled.staticAccountKeys,
    instructions: compiled.compiledInstructions.map((ix) => ({
      programIdIndex: ix.programIdIndex,
      accountIndexes: Array.from(ix.accountKeyIndexes),
      data: Array.from(ix.data),
    })),
    addressTableLookups: compiled.addressTableLookups,
  };

  return serializeMessage(msg);
}

/**
 * Serialize a MegaTransactionMessage struct to SmallVec wire bytes.
 */
export function serializeMessage(msg: MegaTransactionMessage): Buffer {
  // Calculate total size
  let size = 3; // num_signers + num_writable_signers + num_writable_non_signers
  size += 1 + msg.accountKeys.length * 32; // u8 count + pubkeys

  size += 1; // instructions count
  for (const ix of msg.instructions) {
    size += 1; // program_id_index
    size += 1 + ix.accountIndexes.length; // u8 count + indexes
    size += 2 + ix.data.length; // u16 LE count + data
  }

  size += 1; // lookups count
  for (const lookup of msg.addressTableLookups) {
    size += 32; // account_key
    size += 1 + lookup.writableIndexes.length; // u8 count + indexes
    size += 1 + lookup.readonlyIndexes.length; // u8 count + indexes
  }

  const buf = Buffer.alloc(size);
  let offset = 0;

  // Header
  buf.writeUInt8(msg.numSigners, offset++);
  buf.writeUInt8(msg.numWritableSigners, offset++);
  buf.writeUInt8(msg.numWritableNonSigners, offset++);

  // Account keys (u8 length prefix)
  buf.writeUInt8(msg.accountKeys.length, offset++);
  for (const key of msg.accountKeys) {
    key.toBuffer().copy(buf, offset);
    offset += 32;
  }

  // Instructions (u8 length prefix)
  buf.writeUInt8(msg.instructions.length, offset++);
  for (const ix of msg.instructions) {
    buf.writeUInt8(ix.programIdIndex, offset++);
    // account_indexes (u8 length prefix)
    buf.writeUInt8(ix.accountIndexes.length, offset++);
    for (const idx of ix.accountIndexes) {
      buf.writeUInt8(idx, offset++);
    }
    // data (u16 LE length prefix)
    buf.writeUInt16LE(ix.data.length, offset);
    offset += 2;
    for (const byte of ix.data) {
      buf.writeUInt8(byte, offset++);
    }
  }

  // Address table lookups (u8 length prefix)
  buf.writeUInt8(msg.addressTableLookups.length, offset++);
  for (const lookup of msg.addressTableLookups) {
    lookup.accountKey.toBuffer().copy(buf, offset);
    offset += 32;
    // writable_indexes (u8 length prefix)
    buf.writeUInt8(lookup.writableIndexes.length, offset++);
    for (const idx of lookup.writableIndexes) {
      buf.writeUInt8(idx, offset++);
    }
    // readonly_indexes (u8 length prefix)
    buf.writeUInt8(lookup.readonlyIndexes.length, offset++);
    for (const idx of lookup.readonlyIndexes) {
      buf.writeUInt8(idx, offset++);
    }
  }

  return buf;
}

// Deserialize: SmallVec wire bytes → MegaTransactionMessage

/**
 * Deserialize SmallVec wire bytes back into a MegaTransactionMessage.
 * Used when reading a MegaTransaction account's stored message.
 */
export function deserializeMessage(data: Buffer | Uint8Array): MegaTransactionMessage {
  const buf = Buffer.from(data);
  let offset = 0;

  const numSigners = buf.readUInt8(offset++);
  const numWritableSigners = buf.readUInt8(offset++);
  const numWritableNonSigners = buf.readUInt8(offset++);

  // Account keys
  const accountKeysCount = buf.readUInt8(offset++);
  const accountKeys: PublicKey[] = [];
  for (let i = 0; i < accountKeysCount; i++) {
    accountKeys.push(new PublicKey(buf.subarray(offset, offset + 32)));
    offset += 32;
  }

  // Instructions
  const instructionsCount = buf.readUInt8(offset++);
  const instructions: CompiledMsInstruction[] = [];
  for (let i = 0; i < instructionsCount; i++) {
    const programIdIndex = buf.readUInt8(offset++);
    const accountIndexesCount = buf.readUInt8(offset++);
    const accountIndexes: number[] = [];
    for (let j = 0; j < accountIndexesCount; j++) {
      accountIndexes.push(buf.readUInt8(offset++));
    }
    const dataLen = buf.readUInt16LE(offset);
    offset += 2;
    const ixData: number[] = [];
    for (let j = 0; j < dataLen; j++) {
      ixData.push(buf.readUInt8(offset++));
    }
    instructions.push({ programIdIndex, accountIndexes, data: ixData });
  }

  // Address table lookups
  const lookupsCount = buf.readUInt8(offset++);
  const addressTableLookups: MessageAddressTableLookupData[] = [];
  for (let i = 0; i < lookupsCount; i++) {
    const accountKey = new PublicKey(buf.subarray(offset, offset + 32));
    offset += 32;
    const writableCount = buf.readUInt8(offset++);
    const writableIndexes: number[] = [];
    for (let j = 0; j < writableCount; j++) {
      writableIndexes.push(buf.readUInt8(offset++));
    }
    const readonlyCount = buf.readUInt8(offset++);
    const readonlyIndexes: number[] = [];
    for (let j = 0; j < readonlyCount; j++) {
      readonlyIndexes.push(buf.readUInt8(offset++));
    }
    addressTableLookups.push({ accountKey, writableIndexes, readonlyIndexes });
  }

  return {
    numSigners,
    numWritableSigners,
    numWritableNonSigners,
    accountKeys,
    instructions,
    addressTableLookups,
  };
}
