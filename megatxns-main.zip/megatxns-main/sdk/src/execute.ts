import {
  type AccountMeta,
  type AddressLookupTableAccount,
  Connection,
  PublicKey,
  type TransactionInstruction,
} from "@solana/web3.js";
import { PROGRAM_ID } from "./constants.js";
import { getEphemeralSignerPda, getTransactionPda } from "./pdas.js";
import { decodeMegaTransaction } from "./accounts.js";
import type { MegaTransactionMessage } from "./serialization.js";
import { txnExecute } from "./instructions.js";

/**
 * Build remaining accounts for txn_execute in **separated** order:
 *
 *   [ALT accounts, static accounts, ALL loaded writable, ALL loaded readonly]
 *
 * This matches the on-chain validation in `txn_execute.rs`.
 */
export async function buildRemainingAccounts(args: {
  connection: Connection;
  message: MegaTransactionMessage;
  ephemeralSignerBumps: number[];
  creator: PublicKey;
  transactionPda: PublicKey;
  programId?: PublicKey;
}): Promise<{
  accountMetas: AccountMeta[];
  lookupTableAccounts: AddressLookupTableAccount[];
}> {
  const { message, creator, transactionPda, ephemeralSignerBumps } = args;
  const programId = args.programId ?? PROGRAM_ID;

  // Pre-derive ephemeral signer PDAs for signer-check exemption
  const ephemeralSignerPdas = ephemeralSignerBumps.map((_, i) =>
    getEphemeralSignerPda(transactionPda, i, programId)[0]
  );

  // Fetch ALT accounts
  const altKeys = message.addressTableLookups.map((l) => l.accountKey);
  const altAccounts = new Map<string, AddressLookupTableAccount>();
  await Promise.all(
    altKeys.map(async (key) => {
      const { value } = await args.connection.getAddressLookupTable(key);
      if (!value) {
        throw new Error(`Address lookup table ${key.toBase58()} not found`);
      }
      altAccounts.set(key.toBase58(), value);
    })
  );

  const accountMetas: AccountMeta[] = [];

  // 1. ALT account references (readonly, for on-chain ALT validation)
  for (const key of altKeys) {
    accountMetas.push({ pubkey: key, isSigner: false, isWritable: false });
  }

  // 2. Static accounts matching message.accountKeys
  for (let i = 0; i < message.accountKeys.length; i++) {
    const key = message.accountKeys[i];
    const isSigner =
      i < message.numSigners &&
      !key.equals(creator) &&
      !ephemeralSignerPdas.some((p) => key.equals(p));
    const isWritable = isStaticWritableIndex(message, i);
    accountMetas.push({ pubkey: key, isSigner, isWritable });
  }

  // 3. ALL loaded writable (from all ALTs, in order)
  for (const lookup of message.addressTableLookups) {
    const alt = altAccounts.get(lookup.accountKey.toBase58())!;
    for (const idx of lookup.writableIndexes) {
      const pubkey = alt.state.addresses[idx];
      if (!pubkey) {
        throw new Error(
          `ALT ${lookup.accountKey.toBase58()} missing address at index ${idx}`
        );
      }
      accountMetas.push({ pubkey, isSigner: false, isWritable: true });
    }
  }

  // 4. ALL loaded readonly (from all ALTs, in order)
  for (const lookup of message.addressTableLookups) {
    const alt = altAccounts.get(lookup.accountKey.toBase58())!;
    for (const idx of lookup.readonlyIndexes) {
      const pubkey = alt.state.addresses[idx];
      if (!pubkey) {
        throw new Error(
          `ALT ${lookup.accountKey.toBase58()} missing address at index ${idx}`
        );
      }
      accountMetas.push({ pubkey, isSigner: false, isWritable: false });
    }
  }

  return {
    accountMetas,
    lookupTableAccounts: [...altAccounts.values()],
  };
}

function isStaticWritableIndex(
  msg: MegaTransactionMessage,
  index: number
): boolean {
  if (index >= msg.accountKeys.length) return false;
  if (index < msg.numWritableSigners) return true;
  if (index >= msg.numSigners) {
    return index - msg.numSigners < msg.numWritableNonSigners;
  }
  return false;
}

/**
 * High-level: fetch the MegaTransaction account, resolve ALTs, and
 * return a ready-to-send execute instruction.
 */
export async function buildExecuteInstruction(args: {
  connection: Connection;
  creator: PublicKey;
  transactionIndex: number;
  programId?: PublicKey;
}): Promise<{
  instruction: TransactionInstruction;
  lookupTableAccounts: AddressLookupTableAccount[];
}> {
  const programId = args.programId ?? PROGRAM_ID;
  const [transactionPda] = getTransactionPda(
    args.creator,
    args.transactionIndex,
    programId
  );

  const accountInfo = await args.connection.getAccountInfo(transactionPda);
  if (!accountInfo) {
    throw new Error(
      `MegaTransaction account not found: ${transactionPda.toBase58()}`
    );
  }

  const txnAccount = decodeMegaTransaction(accountInfo.data);

  const { accountMetas, lookupTableAccounts } = await buildRemainingAccounts({
    connection: args.connection,
    message: txnAccount.message,
    ephemeralSignerBumps: txnAccount.ephemeralSignerBumps,
    creator: args.creator,
    transactionPda,
    programId,
  });

  return {
    instruction: txnExecute({
      transaction: transactionPda,
      creator: args.creator,
      remainingAccounts: accountMetas,
      programId,
    }),
    lookupTableAccounts,
  };
}
