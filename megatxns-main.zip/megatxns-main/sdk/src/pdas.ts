import { PublicKey } from "@solana/web3.js";
import {
  PROGRAM_ID,
  SEED_PREFIX,
  SEED_TRANSACTION,
  SEED_EPHEMERAL_SIGNER,
  SEED_TRANSACTION_BUFFER,
} from "./constants.js";

export function getTransactionBufferPda(
  creator: PublicKey,
  bufferIndex: number,
  programId = PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [
      SEED_PREFIX,
      SEED_TRANSACTION_BUFFER,
      creator.toBuffer(),
      Buffer.from([bufferIndex]),
    ],
    programId
  );
}

export function getTransactionPda(
  creator: PublicKey,
  transactionIndex: number,
  programId = PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [
      SEED_PREFIX,
      SEED_TRANSACTION,
      creator.toBuffer(),
      Buffer.from([transactionIndex]),
    ],
    programId
  );
}

export function getEphemeralSignerPda(
  transactionPda: PublicKey,
  ephemeralSignerIndex: number,
  programId = PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [
      SEED_PREFIX,
      transactionPda.toBuffer(),
      SEED_EPHEMERAL_SIGNER,
      Buffer.from([ephemeralSignerIndex]),
    ],
    programId
  );
}
