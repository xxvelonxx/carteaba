import { PublicKey } from "@solana/web3.js";

// TODO: Replace with deployed program keypair
export const PROGRAM_ID = new PublicKey(
  "Meg4Txn111111111111111111111111111111111111"
);

export const SEED_PREFIX = Buffer.from("megatxn");
export const SEED_TRANSACTION = Buffer.from("transaction");
export const SEED_EPHEMERAL_SIGNER = Buffer.from("ephemeral_signer");
export const SEED_TRANSACTION_BUFFER = Buffer.from("txn_buffer");

export const MAX_BUFFER_SIZE = 10160;
export const MAX_EPHEMERAL_SIGNERS = 8;

// Account discriminators (first byte of program-owned accounts)
export const ACCOUNT_KEY_MEGA_TRANSACTION = 1;
export const ACCOUNT_KEY_TRANSACTION_BUFFER = 2;

// Account header sizes
export const TRANSACTION_BUFFER_HEADER_LEN = 70;
export const MEGA_TRANSACTION_HEADER_LEN = 34;
