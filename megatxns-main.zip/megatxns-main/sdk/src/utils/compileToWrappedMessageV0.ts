import {
  AddressLookupTableAccount,
  MessageAccountKeys,
  MessageV0,
  PublicKey,
  TransactionInstruction,
  type AccountKeysFromLookups,
  type MessageAddressTableLookup,
} from "@solana/web3.js";
import { CompiledKeys } from "./compiled-keys.js";

/**
 * Compile instructions into a V0 message where instruction programIds
 * can also be resolved from ALTs (unlike the standard compileToV0Message
 * which keeps all programIds as static keys).
 */
export function compileToWrappedMessageV0(args: {
  payerKey: PublicKey;
  recentBlockhash: string;
  instructions: TransactionInstruction[];
  addressLookupTableAccounts?: AddressLookupTableAccount[];
}): MessageV0 {
  const compiledKeys = CompiledKeys.compile(args.instructions, args.payerKey);

  const addressTableLookups: MessageAddressTableLookup[] = [];
  const accountKeysFromLookups: AccountKeysFromLookups = {
    writable: [],
    readonly: [],
  };

  for (const lookupTable of args.addressLookupTableAccounts ?? []) {
    const extractResult = compiledKeys.extractTableLookup(lookupTable);
    if (extractResult !== undefined) {
      const [lookup, { writable, readonly }] = extractResult;
      addressTableLookups.push(lookup);
      accountKeysFromLookups.writable.push(...writable);
      accountKeysFromLookups.readonly.push(...readonly);
    }
  }

  const [header, staticAccountKeys] = compiledKeys.getMessageComponents();
  const accountKeys = new MessageAccountKeys(
    staticAccountKeys,
    accountKeysFromLookups
  );
  const compiledInstructions = accountKeys.compileInstructions(args.instructions);

  return new MessageV0({
    header,
    staticAccountKeys,
    recentBlockhash: args.recentBlockhash,
    compiledInstructions,
    addressTableLookups,
  });
}
