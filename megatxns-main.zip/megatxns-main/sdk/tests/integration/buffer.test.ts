import { describe, it, expect, beforeEach } from "vitest";
import { Keypair } from "@solana/web3.js";
import type { LiteSVM } from "litesvm";
import {
  createTestSvm,
  sendTx,
  sendTxExpectFail,
  getAccountData,
  accountExists,
  sha256,
  buildTransferMessage,
  PROGRAM_ID,
  txnBufferCreate,
  txnBufferExtend,
  txnBufferClose,
  getTransactionBufferPda,
} from "../helpers/setup.js";
import { decodeTransactionBuffer } from "../../src/accounts.js";

describe("Buffer Lifecycle", () => {
  let svm: LiteSVM;
  let payer: Keypair;

  beforeEach(() => {
    svm = createTestSvm();
    payer = Keypair.generate();
    svm.airdrop(payer.publicKey, BigInt(10_000_000_000));
  });

  it("creates buffer with initial slice and verifies header", () => {
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      Keypair.generate().publicKey,
      1_000_000,
      3
    );
    const hash = sha256(messageBytes);
    const bufferIndex = 0;
    const [bufferPda] = getTransactionBufferPda(
      payer.publicKey,
      bufferIndex,
      PROGRAM_ID
    );

    const firstChunk = messageBytes.subarray(0, 100);

    sendTx(
      svm,
      [
        txnBufferCreate({
          bufferIndex,
          finalBufferHash: hash,
          finalBufferSize: messageBytes.length,
          buffer: firstChunk,
          transactionBuffer: bufferPda,
          creator: payer.publicKey,
          rentPayer: payer.publicKey,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );

    const data = getAccountData(svm, bufferPda);
    const decoded = decodeTransactionBuffer(data);

    expect(decoded.accountKey).toBe(2); // TransactionBuffer
    expect(decoded.creator.equals(payer.publicKey)).toBe(true);
    expect(decoded.bufferIndex).toBe(bufferIndex);
    expect(Buffer.from(decoded.finalBufferHash)).toEqual(hash);
    expect(decoded.finalBufferSize).toBe(messageBytes.length);
    expect(decoded.currentSize).toBe(firstChunk.length);
  });

  it("extends buffer with multiple chunks", () => {
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      Keypair.generate().publicKey,
      1_000_000,
      5
    );
    const hash = sha256(messageBytes);
    const bufferIndex = 0;
    const [bufferPda] = getTransactionBufferPda(
      payer.publicKey,
      bufferIndex,
      PROGRAM_ID
    );

    const chunkSize = 80;
    const firstChunk = messageBytes.subarray(0, chunkSize);

    sendTx(
      svm,
      [
        txnBufferCreate({
          bufferIndex,
          finalBufferHash: hash,
          finalBufferSize: messageBytes.length,
          buffer: firstChunk,
          transactionBuffer: bufferPda,
          creator: payer.publicKey,
          rentPayer: payer.publicKey,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );

    // Extend with remaining chunks
    for (let i = chunkSize; i < messageBytes.length; i += chunkSize) {
      const chunk = messageBytes.subarray(
        i,
        Math.min(i + chunkSize, messageBytes.length)
      );
      sendTx(
        svm,
        [
          txnBufferExtend({
            buffer: chunk,
            transactionBuffer: bufferPda,
            creator: payer.publicKey,
            programId: PROGRAM_ID,
          }),
        ],
        [payer]
      );
    }

    const decoded = decodeTransactionBuffer(getAccountData(svm, bufferPda));
    expect(decoded.currentSize).toBe(messageBytes.length);
    expect(Buffer.from(decoded.buffer)).toEqual(messageBytes);
  });

  it("closes buffer and returns rent to creator", () => {
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      Keypair.generate().publicKey,
      1_000_000
    );
    const hash = sha256(messageBytes);
    const bufferIndex = 0;
    const [bufferPda] = getTransactionBufferPda(
      payer.publicKey,
      bufferIndex,
      PROGRAM_ID
    );

    sendTx(
      svm,
      [
        txnBufferCreate({
          bufferIndex,
          finalBufferHash: hash,
          finalBufferSize: messageBytes.length,
          buffer: messageBytes,
          transactionBuffer: bufferPda,
          creator: payer.publicKey,
          rentPayer: payer.publicKey,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );

    const balanceBefore = svm.getBalance(payer.publicKey)!;

    sendTx(
      svm,
      [
        txnBufferClose({
          transactionBuffer: bufferPda,
          creator: payer.publicKey,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );

    const balanceAfter = svm.getBalance(payer.publicKey)!;
    expect(balanceAfter).toBeGreaterThan(balanceBefore);
    expect(accountExists(svm, bufferPda)).toBe(false);
  });

  it("rejects close by non-creator", () => {
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      Keypair.generate().publicKey,
      1_000_000
    );
    const hash = sha256(messageBytes);
    const bufferIndex = 0;
    const [bufferPda] = getTransactionBufferPda(
      payer.publicKey,
      bufferIndex,
      PROGRAM_ID
    );

    sendTx(
      svm,
      [
        txnBufferCreate({
          bufferIndex,
          finalBufferHash: hash,
          finalBufferSize: messageBytes.length,
          buffer: messageBytes,
          transactionBuffer: bufferPda,
          creator: payer.publicKey,
          rentPayer: payer.publicKey,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );

    const attacker = Keypair.generate();
    svm.airdrop(attacker.publicKey, BigInt(1_000_000_000));

    sendTxExpectFail(
      svm,
      [
        txnBufferClose({
          transactionBuffer: bufferPda,
          creator: attacker.publicKey,
          programId: PROGRAM_ID,
        }),
      ],
      [attacker]
    );

    // Buffer should still exist
    expect(accountExists(svm, bufferPda)).toBe(true);
  });
});
