import { describe, it, expect, beforeEach } from "vitest";
import { Keypair } from "@solana/web3.js";
import type { LiteSVM } from "litesvm";
import {
  createTestSvm,
  sendTx,
  sendTxExpectFail,
  accountExists,
  buildTransferMessage,
  createInlineMegaTxn,
  PROGRAM_ID,
  txnClose,
} from "../helpers/setup.js";

describe("Transaction Close", () => {
  let svm: LiteSVM;
  let payer: Keypair;

  beforeEach(() => {
    svm = createTestSvm();
    payer = Keypair.generate();
    svm.airdrop(payer.publicKey, BigInt(10_000_000_000));
  });

  it("closes transaction without executing and returns rent", () => {
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      Keypair.generate().publicKey,
      1_000_000
    );

    const { transactionPda } = createInlineMegaTxn(svm, payer, 0, messageBytes);
    expect(accountExists(svm, transactionPda)).toBe(true);

    const balanceBefore = svm.getBalance(payer.publicKey)!;

    sendTx(
      svm,
      [
        txnClose({
          transaction: transactionPda,
          creator: payer.publicKey,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );

    expect(accountExists(svm, transactionPda)).toBe(false);

    const balanceAfter = svm.getBalance(payer.publicKey)!;
    // Should get rent back (minus tx fee)
    expect(balanceAfter).toBeGreaterThan(balanceBefore);
  });

  it("rejects close by non-creator", () => {
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      Keypair.generate().publicKey,
      1_000_000
    );

    const { transactionPda } = createInlineMegaTxn(svm, payer, 0, messageBytes);

    const attacker = Keypair.generate();
    svm.airdrop(attacker.publicKey, BigInt(1_000_000_000));

    sendTxExpectFail(
      svm,
      [
        txnClose({
          transaction: transactionPda,
          creator: attacker.publicKey,
          programId: PROGRAM_ID,
        }),
      ],
      [attacker]
    );

    expect(accountExists(svm, transactionPda)).toBe(true);
  });
});
