import { describe, it, expect, beforeEach } from "vitest";
import { Keypair, SystemProgram } from "@solana/web3.js";
import type { LiteSVM } from "litesvm";
import {
  createTestSvm,
  sendTx,
  sendTxExpectFail,
  getAccountData,
  accountExists,
  buildTransferMessage,
  createInlineMegaTxn,
  createBufferedMegaTxn,
  buildExecuteRemainingAccounts,
  PROGRAM_ID,
  txnExecute,
  decodeMegaTransaction,
} from "../helpers/setup.js";

describe("Transaction Execute", () => {
  let svm: LiteSVM;
  let payer: Keypair;

  beforeEach(() => {
    svm = createTestSvm();
    payer = Keypair.generate();
    svm.airdrop(payer.publicKey, BigInt(10_000_000_000));
  });

  it("executes simple SOL transfer", () => {
    const recipient = Keypair.generate().publicKey;
    const transferAmount = 1_000_000;
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      recipient,
      transferAmount
    );

    const { transactionPda } = createInlineMegaTxn(svm, payer, 0, messageBytes);

    // Read stored message for remaining accounts
    const txnData = decodeMegaTransaction(getAccountData(svm, transactionPda));
    const remainingAccounts = buildExecuteRemainingAccounts(
      txnData.message,
      payer.publicKey,
      transactionPda,
      txnData.ephemeralSignerBumps
    );

    const recipientBalanceBefore = svm.getBalance(recipient) ?? BigInt(0);

    const result = sendTx(
      svm,
      [
        txnExecute({
          transaction: transactionPda,
          creator: payer.publicKey,
          remainingAccounts,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );

    const recipientBalanceAfter = svm.getBalance(recipient) ?? BigInt(0);
    expect(recipientBalanceAfter - recipientBalanceBefore).toBe(
      BigInt(transferAmount)
    );

    // Transaction account should be closed after execute
    expect(accountExists(svm, transactionPda)).toBe(false);

    console.log(`Execute SOL transfer CU: ${result.computeUnitsConsumed()}`);
  });

  it("executes multiple transfers in one mega transaction", () => {
    const recipient = Keypair.generate().publicKey;
    const transferAmount = 500_000;
    const count = 5;
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      recipient,
      transferAmount,
      count
    );

    const { transactionPda } = createInlineMegaTxn(svm, payer, 0, messageBytes);
    const txnData = decodeMegaTransaction(getAccountData(svm, transactionPda));
    const remainingAccounts = buildExecuteRemainingAccounts(
      txnData.message,
      payer.publicKey,
      transactionPda,
      txnData.ephemeralSignerBumps
    );

    const recipientBalanceBefore = svm.getBalance(recipient) ?? BigInt(0);

    const result = sendTx(
      svm,
      [
        txnExecute({
          transaction: transactionPda,
          creator: payer.publicKey,
          remainingAccounts,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );

    const recipientBalanceAfter = svm.getBalance(recipient) ?? BigInt(0);
    expect(recipientBalanceAfter - recipientBalanceBefore).toBe(
      BigInt(transferAmount * count)
    );

    expect(accountExists(svm, transactionPda)).toBe(false);

    console.log(
      `Execute ${count} transfers CU: ${result.computeUnitsConsumed()}`
    );
  });

  it("creator receives rent back after execute", () => {
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      Keypair.generate().publicKey,
      1_000
    );

    const { transactionPda } = createInlineMegaTxn(svm, payer, 0, messageBytes);
    const txnData = decodeMegaTransaction(getAccountData(svm, transactionPda));
    const remainingAccounts = buildExecuteRemainingAccounts(
      txnData.message,
      payer.publicKey,
      transactionPda,
      txnData.ephemeralSignerBumps
    );

    const balanceBefore = svm.getBalance(payer.publicKey)!;

    sendTx(
      svm,
      [
        txnExecute({
          transaction: transactionPda,
          creator: payer.publicKey,
          remainingAccounts,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );

    const balanceAfter = svm.getBalance(payer.publicKey)!;
    // Balance should increase (rent returned) minus the inner transfer and tx fee
    // At minimum, the rent from the closed account should come back
    // Just verify account was closed — rent math depends on fees
    expect(accountExists(svm, transactionPda)).toBe(false);
  });

  it("rejects execute by wrong creator", () => {
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      Keypair.generate().publicKey,
      1_000
    );

    const { transactionPda } = createInlineMegaTxn(svm, payer, 0, messageBytes);
    const txnData = decodeMegaTransaction(getAccountData(svm, transactionPda));
    const remainingAccounts = buildExecuteRemainingAccounts(
      txnData.message,
      payer.publicKey,
      transactionPda,
      txnData.ephemeralSignerBumps
    );

    const attacker = Keypair.generate();
    svm.airdrop(attacker.publicKey, BigInt(1_000_000_000));

    sendTxExpectFail(
      svm,
      [
        txnExecute({
          transaction: transactionPda,
          creator: attacker.publicKey,
          remainingAccounts,
          programId: PROGRAM_ID,
        }),
      ],
      [attacker]
    );

    // Transaction should still exist
    expect(accountExists(svm, transactionPda)).toBe(true);
  });

  it("executes buffered mega transaction", () => {
    const recipient = Keypair.generate().publicKey;
    const transferAmount = 100_000;
    const count = 10;
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      recipient,
      transferAmount,
      count
    );

    const { transactionPda } = createBufferedMegaTxn(
      svm,
      payer,
      0,
      messageBytes,
      0,
      100
    );

    const txnData = decodeMegaTransaction(getAccountData(svm, transactionPda));
    const remainingAccounts = buildExecuteRemainingAccounts(
      txnData.message,
      payer.publicKey,
      transactionPda,
      txnData.ephemeralSignerBumps
    );

    const recipientBalanceBefore = svm.getBalance(recipient) ?? BigInt(0);

    const result = sendTx(
      svm,
      [
        txnExecute({
          transaction: transactionPda,
          creator: payer.publicKey,
          remainingAccounts,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );

    const recipientBalanceAfter = svm.getBalance(recipient) ?? BigInt(0);
    expect(recipientBalanceAfter - recipientBalanceBefore).toBe(
      BigInt(transferAmount * count)
    );

    expect(accountExists(svm, transactionPda)).toBe(false);

    console.log(
      `Execute buffered ${count} transfers CU: ${result.computeUnitsConsumed()}`
    );
  });
});
