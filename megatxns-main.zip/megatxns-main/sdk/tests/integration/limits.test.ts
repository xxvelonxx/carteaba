import { describe, it, expect, beforeEach } from "vitest";
import {
  Keypair,
  PublicKey,
  SystemProgram,
  TransactionMessage,
  TransactionInstruction,
  ComputeBudgetProgram,
  VersionedTransaction,
  AddressLookupTableAccount,
  AddressLookupTableProgram,
} from "@solana/web3.js";
import type {
  LiteSVM,
  FailedTransactionMetadata,
  TransactionMetadata,
} from "litesvm";
import {
  createTestSvm,
  sendTx,
  getAccountData,
  buildTransferMessage,
  sha256,
  PROGRAM_ID,
  txnBufferCreate,
  txnBufferExtend,
  txnCreateFromBuffer,
  txnExecute,
  getTransactionPda,
  getTransactionBufferPda,
  decodeMegaTransaction,
  buildExecuteRemainingAccounts,
  serializeTransactionMessage,
} from "../helpers/setup.js";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function isFailedTx(
  result: TransactionMetadata | FailedTransactionMetadata
): result is FailedTransactionMetadata {
  return typeof (result as FailedTransactionMetadata).err === "function";
}

/** SetLoadedAccountsDataSizeLimit (ComputeBudget ix index 4). */
function setLoadedAccountsDataSizeLimit(bytes: number): TransactionInstruction {
  const data = Buffer.alloc(5);
  data.writeUInt8(4, 0);
  data.writeUInt32LE(bytes, 1);
  return new TransactionInstruction({
    keys: [],
    programId: ComputeBudgetProgram.programId,
    data,
  });
}

/** Send a V0 transaction, returning success/failure + CU. */
function sendV0Tx(
  svm: LiteSVM,
  ixs: TransactionInstruction[],
  signers: Keypair[],
  lookupTableAccounts: AddressLookupTableAccount[] = []
): { success: boolean; cu: bigint; logs: string } {
  try {
    const message = new TransactionMessage({
      payerKey: signers[0].publicKey,
      recentBlockhash: svm.latestBlockhash(),
      instructions: ixs,
    }).compileToV0Message(lookupTableAccounts);

    const tx = new VersionedTransaction(message);
    tx.sign(signers);

    const result = svm.sendTransaction(tx);
    if (isFailedTx(result)) {
      return {
        success: false,
        cu: result.meta().computeUnitsConsumed(),
        logs: `err: ${result.err()} | ${result.meta().prettyLogs()}`,
      };
    }
    return {
      success: true,
      cu: result.computeUnitsConsumed(),
      logs: result.prettyLogs(),
    };
  } catch (e: any) {
    return { success: false, cu: 0n, logs: `JS error: ${e.message}` };
  }
}

/**
 * Create an on-chain ALT containing the given addresses.
 * Warp forward one slot so it becomes usable.
 */
function createAlt(
  svm: LiteSVM,
  payer: Keypair,
  addresses: PublicKey[]
): { altKey: PublicKey; altAccount: AddressLookupTableAccount } {
  const [createIx, altKey] = AddressLookupTableProgram.createLookupTable({
    authority: payer.publicKey,
    payer: payer.publicKey,
    recentSlot: 0,
  });

  const BATCH_SIZE = 20;
  const firstBatch = addresses.slice(0, BATCH_SIZE);
  const extendIx = AddressLookupTableProgram.extendLookupTable({
    lookupTable: altKey,
    authority: payer.publicKey,
    payer: payer.publicKey,
    addresses: firstBatch,
  });
  sendTx(svm, [createIx, extendIx], [payer]);

  for (let i = BATCH_SIZE; i < addresses.length; i += BATCH_SIZE) {
    const batch = addresses.slice(i, i + BATCH_SIZE);
    const ix = AddressLookupTableProgram.extendLookupTable({
      lookupTable: altKey,
      authority: payer.publicKey,
      payer: payer.publicKey,
      addresses: batch,
    });
    sendTx(svm, [ix], [payer]);
  }

  svm.warpToSlot(svm.getClock().slot + 1n);

  const altData = svm.getAccount(altKey);
  if (!altData) throw new Error("ALT not found after creation");
  const altAccount = new AddressLookupTableAccount({
    key: altKey,
    state: AddressLookupTableAccount.deserialize(altData.data),
  });

  return { altKey, altAccount };
}

/**
 * Create MegaTransaction via buffer flow and execute with V0 tx + ALTs.
 */
function createAndExecuteV0(
  svm: LiteSVM,
  payer: Keypair,
  messageBytes: Buffer,
  txnIndex: number,
  outerAltAccounts: AddressLookupTableAccount[] = [],
  computeUnits = 1_400_000
): { success: boolean; cu: bigint; logs: string } {
  try {
    const bufferIndex = txnIndex;
    const [bufferPda] = getTransactionBufferPda(payer.publicKey, bufferIndex, PROGRAM_ID);
    const hash = sha256(messageBytes);
    const chunkSize = 700;

    // Create buffer
    sendTx(
      svm,
      [
        txnBufferCreate({
          bufferIndex,
          finalBufferHash: hash,
          finalBufferSize: messageBytes.length,
          buffer: messageBytes.subarray(0, chunkSize),
          transactionBuffer: bufferPda,
          creator: payer.publicKey,
          rentPayer: payer.publicKey,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );

    // Extend
    for (let i = chunkSize; i < messageBytes.length; i += chunkSize) {
      sendTx(
        svm,
        [
          txnBufferExtend({
            buffer: messageBytes.subarray(i, i + chunkSize),
            transactionBuffer: bufferPda,
            creator: payer.publicKey,
            programId: PROGRAM_ID,
          }),
        ],
        [payer]
      );
    }

    // Create from buffer
    const [transactionPda] = getTransactionPda(payer.publicKey, txnIndex, PROGRAM_ID);
    sendTx(
      svm,
      [
        txnCreateFromBuffer({
          transactionIndex: txnIndex,
          ephemeralSigners: 0,
          transaction: transactionPda,
          creator: payer.publicKey,
          rentPayer: payer.publicKey,
          transactionBuffer: bufferPda,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );

    // Execute
    const txnData = decodeMegaTransaction(getAccountData(svm, transactionPda));
    const remainingAccounts = buildExecuteRemainingAccounts(
      txnData.message,
      payer.publicKey,
      transactionPda,
      txnData.ephemeralSignerBumps
    );

    return sendV0Tx(
      svm,
      [
        ComputeBudgetProgram.setComputeUnitLimit({ units: computeUnits }),
        setLoadedAccountsDataSizeLimit(128 * 1024 * 1024),
        txnExecute({
          transaction: transactionPda,
          creator: payer.publicKey,
          remainingAccounts,
          programId: PROGRAM_ID,
        }),
      ],
      [payer],
      outerAltAccounts
    );
  } catch (e: any) {
    return { success: false, cu: 0n, logs: `setup error: ${e.message}` };
  }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("Limits (VersionedTransaction + ALTs)", () => {
  let svm: LiteSVM;
  let payer: Keypair;

  beforeEach(() => {
    svm = createTestSvm();
    payer = Keypair.generate();
    svm.airdrop(payer.publicKey, BigInt(100_000_000_000));
  });

  describe("account scaling without ALTs (legacy tx)", () => {
    const counts = [5, 10, 15, 20, 25];

    it.each(counts)("%i recipients", (n) => {
      const recipients = Array.from(
        { length: n },
        () => Keypair.generate().publicKey
      );
      const ixs = recipients.map((r) =>
        SystemProgram.transfer({
          fromPubkey: payer.publicKey,
          toPubkey: r,
          lamports: 1_000,
        })
      );
      const message = new TransactionMessage({
        payerKey: payer.publicKey,
        recentBlockhash: PublicKey.default.toString(),
        instructions: ixs,
      });
      const messageBytes = serializeTransactionMessage(message);

      const { success, cu } = createAndExecuteV0(svm, payer, messageBytes, n);
      console.log(
        `  ${n} recipients (${n + 2} accts, no ALT): ${success ? `${cu} CU` : "FAILED"}`
      );
    });
  });

  describe("account scaling with outer ALTs", () => {
    const counts = [10, 20, 30, 40, 50, 60];

    it.each(counts)("%i recipients (V0 + ALT)", (n) => {
      const recipients = Array.from(
        { length: n },
        () => Keypair.generate().publicKey
      );

      const { altAccount } = createAlt(svm, payer, [
        ...recipients,
        SystemProgram.programId,
      ]);

      const ixs = recipients.map((r) =>
        SystemProgram.transfer({
          fromPubkey: payer.publicKey,
          toPubkey: r,
          lamports: 1_000,
        })
      );
      const message = new TransactionMessage({
        payerKey: payer.publicKey,
        recentBlockhash: PublicKey.default.toString(),
        instructions: ixs,
      });
      const messageBytes = serializeTransactionMessage(message);

      const { success, cu, logs } = createAndExecuteV0(
        svm, payer, messageBytes, n, [altAccount]
      );

      console.log(
        `  ${n} recipients (${n + 2} accts, V0+ALT): ${success ? `${cu} CU` : "FAILED"}`
      );
      if (!success) console.log(`    ERR: ${logs.slice(0, 300)}`);

      if (success) {
        for (const r of recipients) {
          expect(svm.getBalance(r) ?? 0n).toBe(1000n);
        }
      }
    });
  });

  describe("inner instruction scaling", () => {
    const counts = [10, 20, 30, 40, 50, 60];

    it.each(counts)("%i transfers (V0)", (count) => {
      const recipient = Keypair.generate().publicKey;
      const msg = buildTransferMessage(payer.publicKey, recipient, 1_000, count);

      const { success, cu } = createAndExecuteV0(svm, payer, msg, count);
      console.log(
        `  ${count} transfers (V0): ${success ? `${cu} CU` : "FAILED"}`
      );
    });
  });
});
