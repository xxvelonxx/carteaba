import { describe, it, expect } from "vitest";
import {
  Keypair,
  PublicKey,
  Transaction,
  SystemProgram,
  TransactionMessage,
} from "@solana/web3.js";
import type {
  LiteSVM,
  FailedTransactionMetadata,
  TransactionMetadata,
} from "litesvm";
import {
  createTestSvm,
  sendTx,
  getAccountData,
  buildTransferMessage,
  PROGRAM_ID,
  txnCreate,
  txnExecute,
  getTransactionPda,
  decodeMegaTransaction,
  buildExecuteRemainingAccounts,
  serializeTransactionMessage,
} from "../helpers/setup.js";

function isFailedTx(
  result: TransactionMetadata | FailedTransactionMetadata
): result is FailedTransactionMetadata {
  return typeof (result as FailedTransactionMetadata).err === "function";
}

/**
 * Create a MegaTransaction and execute it, returning CU consumed.
 */
function createAndExecute(
  svm: LiteSVM,
  payer: Keypair,
  messageBytes: Buffer,
  txnIndex = 0
): { success: boolean; cu: bigint } {
  const [transactionPda] = getTransactionPda(
    payer.publicKey,
    txnIndex,
    PROGRAM_ID
  );

  sendTx(
    svm,
    [
      txnCreate({
        transactionIndex: txnIndex,
        ephemeralSigners: 0,
        transactionMessage: messageBytes,
        transaction: transactionPda,
        creator: payer.publicKey,
        rentPayer: payer.publicKey,
        programId: PROGRAM_ID,
      }),
    ],
    [payer]
  );

  const txnData = decodeMegaTransaction(getAccountData(svm, transactionPda));
  const remainingAccounts = buildExecuteRemainingAccounts(
    txnData.message,
    payer.publicKey,
    transactionPda,
    txnData.ephemeralSignerBumps
  );

  const tx = new Transaction();
  tx.add(
    txnExecute({
      transaction: transactionPda,
      creator: payer.publicKey,
      remainingAccounts,
      programId: PROGRAM_ID,
    })
  );
  tx.recentBlockhash = svm.latestBlockhash();
  tx.feePayer = payer.publicKey;
  tx.sign(payer);

  const result = svm.sendTransaction(tx);
  if (isFailedTx(result)) {
    return { success: false, cu: result.meta().computeUnitsConsumed() };
  }
  return { success: true, cu: result.computeUnitsConsumed() };
}

type BenchResult = { test: string; cu: bigint; success: boolean };

describe("CU Report", () => {
  const results: BenchResult[] = [];

  const transferCases = [
    { name: "1 transfer", count: 1 },
    { name: "10 transfers", count: 10 },
    { name: "20 transfers", count: 20 },
    { name: "49 transfers", count: 49 },
  ];

  it.each(transferCases)("$name (same recipient)", ({ name, count }) => {
    const svm = createTestSvm();
    const payer = Keypair.generate();
    svm.airdrop(payer.publicKey, BigInt(100_000_000_000));

    const msg = buildTransferMessage(
      payer.publicKey,
      Keypair.generate().publicKey,
      1_000,
      count
    );
    const { success, cu } = createAndExecute(svm, payer, msg);
    results.push({ test: name, cu, success });

    console.log(`  ${name}: ${success ? `${cu} CU` : "FAILED"}`);
    expect(success).toBe(true);
  });

  it("10 transfers to 10 different recipients", () => {
    const svm = createTestSvm();
    const payer = Keypair.generate();
    svm.airdrop(payer.publicKey, BigInt(100_000_000_000));

    const recipients = Array.from(
      { length: 10 },
      () => Keypair.generate().publicKey
    );
    const ixs = recipients.map((r) =>
      SystemProgram.transfer({
        fromPubkey: payer.publicKey,
        toPubkey: r,
        lamports: 1_000,
      })
    );
    const message = new TransactionMessage({
      payerKey: payer.publicKey,
      recentBlockhash: PublicKey.default.toString(),
      instructions: ixs,
    });
    const messageBytes = serializeTransactionMessage(message);
    const { success, cu } = createAndExecute(svm, payer, messageBytes);
    results.push({ test: "10 recipients", cu, success });

    console.log(`  10 different recipients: ${success ? `${cu} CU` : "FAILED"}`);
    expect(success).toBe(true);
  });

  it("prints summary", () => {
    console.log("\n┌─────────────────────────┬──────────┬────────┐");
    console.log("│ Test                    │ CU       │ Status │");
    console.log("├─────────────────────────┼──────────┼────────┤");
    for (const r of results) {
      const label = r.test.padEnd(23);
      const cu = r.success ? String(r.cu).padStart(8) : "     N/A";
      const status = r.success ? "  OK  " : " FAIL ";
      console.log(`│ ${label} │ ${cu} │${status}│`);
    }
    console.log("└─────────────────────────┴──────────┴────────┘");
  });
});
