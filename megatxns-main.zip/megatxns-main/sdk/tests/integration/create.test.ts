import { describe, it, expect, beforeEach } from "vitest";
import { Keypair } from "@solana/web3.js";
import type { LiteSVM } from "litesvm";
import {
  createTestSvm,
  sendTx,
  sendTxExpectFail,
  getAccountData,
  accountExists,
  sha256,
  buildTransferMessage,
  createInlineMegaTxn,
  createBufferedMegaTxn,
  PROGRAM_ID,
  txnCreate,
  txnBufferCreate,
  txnBufferExtend,
  txnCreateFromBuffer,
  getTransactionPda,
  getTransactionBufferPda,
  decodeMegaTransaction,
} from "../helpers/setup.js";

describe("Transaction Create (inline)", () => {
  let svm: LiteSVM;
  let payer: Keypair;

  beforeEach(() => {
    svm = createTestSvm();
    payer = Keypair.generate();
    svm.airdrop(payer.publicKey, BigInt(10_000_000_000));
  });

  it("creates transaction with simple transfer message", () => {
    const recipient = Keypair.generate().publicKey;
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      recipient,
      1_000_000
    );

    const { transactionPda } = createInlineMegaTxn(svm, payer, 0, messageBytes);

    const data = getAccountData(svm, transactionPda);
    const decoded = decodeMegaTransaction(data);

    expect(decoded.accountKey).toBe(1); // MegaTransaction
    expect(decoded.creator.equals(payer.publicKey)).toBe(true);
    expect(decoded.ephemeralSignerCount).toBe(0);
    expect(decoded.ephemeralSignerBumps).toHaveLength(0);
    expect(decoded.message.accountKeys.length).toBeGreaterThan(0);
    expect(decoded.message.instructions.length).toBe(1);
  });

  it("creates transaction with multiple inner instructions", () => {
    const recipient = Keypair.generate().publicKey;
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      recipient,
      1_000_000,
      5
    );

    const { transactionPda } = createInlineMegaTxn(svm, payer, 0, messageBytes);
    const decoded = decodeMegaTransaction(getAccountData(svm, transactionPda));

    expect(decoded.message.instructions.length).toBe(5);
  });

  it("creates with ephemeral signers and stores bumps", () => {
    const recipient = Keypair.generate().publicKey;
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      recipient,
      1_000_000
    );

    const { transactionPda } = createInlineMegaTxn(
      svm,
      payer,
      0,
      messageBytes,
      2 // 2 ephemeral signers
    );
    const decoded = decodeMegaTransaction(getAccountData(svm, transactionPda));

    expect(decoded.ephemeralSignerCount).toBe(2);
    expect(decoded.ephemeralSignerBumps).toHaveLength(2);
    // Bumps should be valid (non-zero in almost all cases)
    for (const bump of decoded.ephemeralSignerBumps) {
      expect(bump).toBeGreaterThan(0);
      expect(bump).toBeLessThanOrEqual(255);
    }
  });

  it("rejects >8 ephemeral signers", () => {
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      Keypair.generate().publicKey,
      1_000_000
    );
    const [transactionPda] = getTransactionPda(
      payer.publicKey,
      0,
      PROGRAM_ID
    );

    sendTxExpectFail(
      svm,
      [
        txnCreate({
          transactionIndex: 0,
          ephemeralSigners: 9,
          transactionMessage: messageBytes,
          transaction: transactionPda,
          creator: payer.publicKey,
          rentPayer: payer.publicKey,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );
  });
});

describe("Transaction Create (from buffer)", () => {
  let svm: LiteSVM;
  let payer: Keypair;

  beforeEach(() => {
    svm = createTestSvm();
    payer = Keypair.generate();
    svm.airdrop(payer.publicKey, BigInt(10_000_000_000));
  });

  it("full buffered flow: create → extend → create_from_buffer", () => {
    const recipient = Keypair.generate().publicKey;
    // Build a large-ish message that requires multiple chunks
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      recipient,
      1_000_000,
      10
    );

    const { transactionPda } = createBufferedMegaTxn(
      svm,
      payer,
      0,
      messageBytes,
      0,
      100 // small chunks to force multiple extends
    );

    const decoded = decodeMegaTransaction(getAccountData(svm, transactionPda));
    expect(decoded.message.instructions.length).toBe(10);
    expect(decoded.creator.equals(payer.publicKey)).toBe(true);
  });

  it("buffer is closed after create_from_buffer", () => {
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      Keypair.generate().publicKey,
      1_000_000,
      3
    );

    const bufferIndex = 0;
    const [bufferPda] = getTransactionBufferPda(
      payer.publicKey,
      bufferIndex,
      PROGRAM_ID
    );

    createBufferedMegaTxn(svm, payer, 0, messageBytes);

    // Buffer should be closed
    expect(accountExists(svm, bufferPda)).toBe(false);
  });

  it("rejects incomplete buffer (size mismatch)", () => {
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      Keypair.generate().publicKey,
      1_000_000,
      3
    );
    const hash = sha256(messageBytes);
    const bufferIndex = 0;
    const [bufferPda] = getTransactionBufferPda(
      payer.publicKey,
      bufferIndex,
      PROGRAM_ID
    );

    // Create buffer but DON'T extend to full size
    const partialChunk = messageBytes.subarray(0, 50);
    sendTx(
      svm,
      [
        txnBufferCreate({
          bufferIndex,
          finalBufferHash: hash,
          finalBufferSize: messageBytes.length,
          buffer: partialChunk,
          transactionBuffer: bufferPda,
          creator: payer.publicKey,
          rentPayer: payer.publicKey,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );

    // Try to create from incomplete buffer — should fail
    const [transactionPda] = getTransactionPda(
      payer.publicKey,
      0,
      PROGRAM_ID
    );
    sendTxExpectFail(
      svm,
      [
        txnCreateFromBuffer({
          transactionIndex: 0,
          ephemeralSigners: 0,
          transaction: transactionPda,
          creator: payer.publicKey,
          rentPayer: payer.publicKey,
          transactionBuffer: bufferPda,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );
  });

  it("rejects wrong hash", () => {
    const messageBytes = buildTransferMessage(
      payer.publicKey,
      Keypair.generate().publicKey,
      1_000_000
    );
    const wrongHash = sha256(Buffer.from("wrong data"));
    const bufferIndex = 0;
    const [bufferPda] = getTransactionBufferPda(
      payer.publicKey,
      bufferIndex,
      PROGRAM_ID
    );

    // Create buffer with wrong hash but correct data
    sendTx(
      svm,
      [
        txnBufferCreate({
          bufferIndex,
          finalBufferHash: wrongHash,
          finalBufferSize: messageBytes.length,
          buffer: messageBytes,
          transactionBuffer: bufferPda,
          creator: payer.publicKey,
          rentPayer: payer.publicKey,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );

    const [transactionPda] = getTransactionPda(
      payer.publicKey,
      0,
      PROGRAM_ID
    );
    sendTxExpectFail(
      svm,
      [
        txnCreateFromBuffer({
          transactionIndex: 0,
          ephemeralSigners: 0,
          transaction: transactionPda,
          creator: payer.publicKey,
          rentPayer: payer.publicKey,
          transactionBuffer: bufferPda,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );
  });
});
