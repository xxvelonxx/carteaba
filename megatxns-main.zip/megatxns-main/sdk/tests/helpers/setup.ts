import {
  LiteSVM,
  type FailedTransactionMetadata,
  type TransactionMetadata,
} from "litesvm";
import {
  Keypair,
  PublicKey,
  Transaction,
  TransactionInstruction,
  TransactionMessage,
  SystemProgram,
} from "@solana/web3.js";
import * as crypto from "node:crypto";
import path from "node:path";

import {
  getTransactionBufferPda,
  getTransactionPda,
  serializeTransactionMessage,
  txnBufferCreate,
  txnBufferExtend,
  txnCreateFromBuffer,
  txnCreate,
  txnExecute,
  txnClose,
  txnBufferClose,
  decodeMegaTransaction,
  type MegaTransactionMessage,
} from "../../src/index.js";

// Constants

const DEPLOY_DIR = path.resolve(__dirname, "../../../target/deploy");
const MEGATXN_SO = path.join(DEPLOY_DIR, "megatxn.so");

export const PROGRAM_ID = new PublicKey(
  "Meg4Txn111111111111111111111111111111111111"
);

// SVM Factory

export function createTestSvm(): LiteSVM {
  const svm = new LiteSVM();
  svm.addProgramFromFile(PROGRAM_ID, MEGATXN_SO);
  return svm;
}

// Transaction helpers

function isFailedTx(
  result: TransactionMetadata | FailedTransactionMetadata
): result is FailedTransactionMetadata {
  return typeof (result as FailedTransactionMetadata).err === "function";
}

export function sendTx(
  svm: LiteSVM,
  ixs: TransactionInstruction[],
  signers: Keypair[]
): TransactionMetadata {
  const tx = new Transaction();
  for (const ix of ixs) tx.add(ix);
  tx.recentBlockhash = svm.latestBlockhash();
  tx.feePayer = signers[0].publicKey;
  tx.sign(...signers);

  const result = svm.sendTransaction(tx);
  if (isFailedTx(result)) {
    throw new Error(`Transaction failed:\n${result.meta().prettyLogs()}`);
  }
  return result;
}

export function sendTxExpectFail(
  svm: LiteSVM,
  ixs: TransactionInstruction[],
  signers: Keypair[]
): FailedTransactionMetadata {
  const tx = new Transaction();
  for (const ix of ixs) tx.add(ix);
  tx.recentBlockhash = svm.latestBlockhash();
  tx.feePayer = signers[0].publicKey;
  tx.sign(...signers);

  const result = svm.sendTransaction(tx);
  if (!isFailedTx(result)) {
    throw new Error("Expected transaction to fail, but it succeeded");
  }
  return result;
}

export function getAccountData(svm: LiteSVM, addr: PublicKey): Uint8Array {
  const acct = svm.getAccount(addr);
  if (!acct) throw new Error(`Account not found: ${addr.toBase58()}`);
  return acct.data;
}

export function accountExists(svm: LiteSVM, addr: PublicKey): boolean {
  return svm.getAccount(addr) !== null;
}

// Message building helpers

/**
 * Build a simple SOL transfer TransactionMessage and serialize to SmallVec.
 */
export function buildTransferMessage(
  payer: PublicKey,
  recipient: PublicKey,
  lamports: number,
  count = 1
): Buffer {
  const ixs: TransactionInstruction[] = [];
  for (let i = 0; i < count; i++) {
    ixs.push(
      SystemProgram.transfer({
        fromPubkey: payer,
        toPubkey: recipient,
        lamports,
      })
    );
  }

  const message = new TransactionMessage({
    payerKey: payer,
    recentBlockhash: PublicKey.default.toString(),
    instructions: ixs,
  });

  return serializeTransactionMessage(message);
}

/**
 * SHA-256 hash of a buffer.
 */
export function sha256(data: Buffer | Uint8Array): Buffer {
  return crypto.createHash("sha256").update(data).digest();
}

// Full-flow helpers

/**
 * Create a MegaTransaction from an inline message (fits in one tx).
 * Returns the transaction PDA.
 */
export function createInlineMegaTxn(
  svm: LiteSVM,
  payer: Keypair,
  transactionIndex: number,
  messageBytes: Buffer,
  ephemeralSigners = 0
): { transactionPda: PublicKey; result: TransactionMetadata } {
  const [transactionPda] = getTransactionPda(
    payer.publicKey,
    transactionIndex,
    PROGRAM_ID
  );

  const ix = txnCreate({
    transactionIndex,
    ephemeralSigners,
    transactionMessage: messageBytes,
    transaction: transactionPda,
    creator: payer.publicKey,
    rentPayer: payer.publicKey,
    programId: PROGRAM_ID,
  });

  const result = sendTx(svm, [ix], [payer]);
  return { transactionPda, result };
}

/**
 * Create a MegaTransaction via the buffer flow (for large messages).
 * Returns the transaction PDA.
 */
export function createBufferedMegaTxn(
  svm: LiteSVM,
  payer: Keypair,
  transactionIndex: number,
  messageBytes: Buffer,
  ephemeralSigners = 0,
  chunkSize = 700
): { transactionPda: PublicKey } {
  const bufferIndex = transactionIndex; // reuse index for simplicity
  const [bufferPda] = getTransactionBufferPda(
    payer.publicKey,
    bufferIndex,
    PROGRAM_ID
  );
  const hash = sha256(messageBytes);

  // Create buffer with first chunk
  const firstChunk = messageBytes.subarray(0, chunkSize);
  sendTx(
    svm,
    [
      txnBufferCreate({
        bufferIndex,
        finalBufferHash: hash,
        finalBufferSize: messageBytes.length,
        buffer: firstChunk,
        transactionBuffer: bufferPda,
        creator: payer.publicKey,
        rentPayer: payer.publicKey,
        programId: PROGRAM_ID,
      }),
    ],
    [payer]
  );

  // Extend with remaining chunks
  for (let i = chunkSize; i < messageBytes.length; i += chunkSize) {
    const chunk = messageBytes.subarray(i, i + chunkSize);
    sendTx(
      svm,
      [
        txnBufferExtend({
          buffer: chunk,
          transactionBuffer: bufferPda,
          creator: payer.publicKey,
          programId: PROGRAM_ID,
        }),
      ],
      [payer]
    );
  }

  // Create from buffer
  const [transactionPda] = getTransactionPda(
    payer.publicKey,
    transactionIndex,
    PROGRAM_ID
  );
  sendTx(
    svm,
    [
      txnCreateFromBuffer({
        transactionIndex,
        ephemeralSigners,
        transaction: transactionPda,
        creator: payer.publicKey,
        rentPayer: payer.publicKey,
        transactionBuffer: bufferPda,
        programId: PROGRAM_ID,
      }),
    ],
    [payer]
  );

  return { transactionPda };
}

/**
 * Build remaining accounts for execute from a stored MegaTransaction.
 * For simple cases (no ALTs), this just reads the stored message and
 * builds the account list.
 */
export function buildExecuteRemainingAccounts(
  message: MegaTransactionMessage,
  creator: PublicKey,
  transactionPda: PublicKey,
  ephemeralSignerBumps: number[]
): { pubkey: PublicKey; isSigner: boolean; isWritable: boolean }[] {
  const metas: { pubkey: PublicKey; isSigner: boolean; isWritable: boolean }[] =
    [];

  // No ALTs in simple tests — skip step 1

  // Step 2: static accounts
  for (let i = 0; i < message.accountKeys.length; i++) {
    const key = message.accountKeys[i];
    const isSigner = i < message.numSigners && !key.equals(creator);
    const isWritable =
      i < message.numWritableSigners ||
      (i >= message.numSigners &&
        i - message.numSigners < message.numWritableNonSigners);
    metas.push({ pubkey: key, isSigner, isWritable });
  }

  // Steps 3 & 4: no ALTs in simple tests

  return metas;
}

// Re-export SDK types for test convenience
export {
  txnBufferCreate,
  txnBufferExtend,
  txnBufferClose,
  txnCreate,
  txnCreateFromBuffer,
  txnExecute,
  txnClose,
  getTransactionBufferPda,
  getTransactionPda,
  decodeMegaTransaction,
  serializeTransactionMessage,
};
